package com.example.navigatorapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.widget.Button;
import android.widget.TextView;

import com.example.navigatorapp.other.CommonMethods;

import java.util.HashMap;

public class Activity03_SalesToday extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity03_sales_today);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        @SuppressWarnings("unchecked")
        HashMap<String,String> salesToday = (HashMap<String, String>)getIntent().getSerializableExtra("salesToday");
        System.out.println("-----> IN ACTIV03 BEFORE SETTING TO UI --> "+salesToday);
        setDataToUI(salesToday);
        CommonMethods.setTestData(salesToday);

        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Activity03_SalesToday.this, Activity02_Create.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
            navToActivity(Activity03_SalesToday.this, Activity01_Home.class);
        } else if (id == R.id.nav_create) {
            navToActivity(Activity03_SalesToday.this, Activity02_Create.class);
        } else if (id == R.id.nav_search_sales) {
            navToActivity(Activity03_SalesToday.this, Activity04_Search_Sales.class);
        } else if (id == R.id.nav_custom_search) {
            navToActivity(Activity03_SalesToday.this, Activity06_Create_Report.class);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void navToActivity(Context context, Class<?> cls) {
        Intent intent = new Intent(context, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    public void setDataToUI(HashMap<String,String> salesToday) {
        TextView dateObj = (TextView) findViewById(R.id.date_textView6);
        TextView prevRollingObj = (TextView) findViewById(R.id.PREV_ROLLING_textView6);
        TextView expenseObj = (TextView) findViewById(R.id.EXPENSE_textView6);
        TextView cashBalObj = (TextView) findViewById(R.id.CASH_BAL_textView6);
        TextView bonusObj = (TextView) findViewById(R.id.BONUS_textView6);
        TextView cashBalAfterBonusObj = (TextView) findViewById(R.id.CASH_BAL_AFTER_BONUS_textView6);
        TextView businessTodayObj = (TextView) findViewById(R.id.BUSINESS_TODAY_textView6);
        TextView addRollFromBoxObj = (TextView) findViewById(R.id.ADDITIONAL_ROLL_BOX_textView6);
        TextView addRollFromTSObj = (TextView) findViewById(R.id.ADDITIONAL_ROLL_TS_textView6);
        TextView rollTomorrowObj = (TextView) findViewById(R.id.ROLL_TOMORROW_textView6);
        TextView prevBoxDeficitObj = (TextView) findViewById(R.id.PREV_BOX_DEFICIT_textView6);
        TextView savingsToReduceBoxDefObj = (TextView) findViewById(R.id.SAVINGS_TO_REDUCE_BOX_DEFICIT_textView6);
        TextView boxDeficitTodayObj = (TextView) findViewById(R.id.BOX_DEFICIT_TODAY_textView6);
        TextView electricityObj = (TextView) findViewById(R.id.ELECTRICITY_textView6);
        TextView salaryObj = (TextView) findViewById(R.id.SALARY_textView6);
        TextView prevBoxSavingsObj = (TextView) findViewById(R.id.PREV_BOX_SAVINGS_textView6);
        TextView boxSavingsTodayObj = (TextView) findViewById(R.id.BOX_SAVINGS_TODAY_textView6);
        TextView boxAmtToTsObj = (TextView) findViewById(R.id.BOX_AMT_TO_TS_textView6);
        TextView urbanCollObj = (TextView) findViewById(R.id.URBAN_COLLECTION_textView6);
        TextView prevTotSavObj = (TextView) findViewById(R.id.PREV_TOTAL_SAVINGS_textView6);
        TextView savingsTodayObj = (TextView) findViewById(R.id.SAVINGS_TODAY_textView6);
        TextView totalSavingsTodayObj = (TextView) findViewById(R.id.TOTAL_SAVINGS_TODAY_textView6);
        TextView transfTSToBankObj = (TextView) findViewById(R.id.TRANSFERRED_TS_TO_BANK_textView6);
        TextView emp1SalaryObj = (TextView) findViewById(R.id.emp1Salary_textView6);
        TextView emp2SalaryObj = (TextView) findViewById(R.id.emp2Salary_textView6);
        TextView emp1BonusObj = (TextView) findViewById(R.id.emp1Bonus_textView6);
        TextView emp2BonusObj = (TextView) findViewById(R.id.emp2Bonus_textView6);
        TextView emp3BonusObj = (TextView) findViewById(R.id.emp3Bonus_textView6);
        TextView addWithdrawlFromTS = (TextView) findViewById(R.id.addWithdrawalFromTS_textView6);

        String tempDate = salesToday.get("DATE");
        dateObj.setText(tempDate.substring(6,8)+"-"+tempDate.substring(4,6)+"-"+tempDate.substring(0,4));
        prevRollingObj.setText(salesToday.get("PREV_ROLLING"));
        expenseObj.setText(salesToday.get("EXPENSE"));
        cashBalObj.setText(salesToday.get("CASH_BAL"));
        bonusObj.setText(salesToday.get("BONUS"));
        cashBalAfterBonusObj.setText(salesToday.get("CASH_BAL_AFTER_BONUS"));
        businessTodayObj.setText(salesToday.get("BUSINESS_TODAY"));
        addRollFromBoxObj.setText(salesToday.get("ADDITIONAL_ROLL_BOX"));
        addRollFromTSObj.setText(salesToday.get("ADDITIONAL_ROLL_TS"));
        rollTomorrowObj.setText(salesToday.get("ROLL_TOMORROW"));
        prevBoxDeficitObj.setText(salesToday.get("PREV_BOX_DEFICIT"));
        savingsToReduceBoxDefObj.setText(salesToday.get("SAVINGS_TO_REDUCE_BOX_DEFICIT"));
        boxDeficitTodayObj.setText(salesToday.get("BOX_DEFICIT_TODAY"));
        electricityObj.setText(salesToday.get("ELECTRICITY"));
        salaryObj.setText(salesToday.get("SALARY"));
        prevBoxSavingsObj.setText(salesToday.get("PREV_BOX_SAVINGS"));
        boxSavingsTodayObj.setText(salesToday.get("BOX_SAVINGS_TODAY"));
        boxAmtToTsObj.setText(salesToday.get("BOX_AMT_TO_TS"));
        urbanCollObj.setText(salesToday.get("URBAN_COLLECTION"));
        prevTotSavObj.setText(salesToday.get("PREV_TOTAL_SAVINGS"));
        savingsTodayObj.setText(salesToday.get("SAVINGS_TODAY"));
        totalSavingsTodayObj.setText(salesToday.get("TOTAL_SAVINGS_TODAY"));
        transfTSToBankObj.setText(salesToday.get("TRANSFERRED_TS_TO_BANK"));
        emp1SalaryObj.setText(salesToday.get("EMP1_SALARY"));
        emp2SalaryObj.setText(salesToday.get("EMP2_SALARY"));
        emp1BonusObj.setText(salesToday.get("EMP1_BONUS"));
        emp2BonusObj.setText(salesToday.get("EMP2_BONUS"));
        emp3BonusObj.setText(salesToday.get("EMP3_BONUS"));
        addWithdrawlFromTS.setText(salesToday.get("ADD_WITHDRAWL_TS"));
    }
}
