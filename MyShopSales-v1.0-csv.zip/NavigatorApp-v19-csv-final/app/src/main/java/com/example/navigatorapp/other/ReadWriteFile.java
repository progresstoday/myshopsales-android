package com.example.navigatorapp.other;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class ReadWriteFile {
    //Initial Write
    public static String initialWriteFile(String filePath) {
        String msg = null;
        try {
            File file = new File(filePath);
            if(!file.exists()) {
                System.out.println("Creating..");
                file.createNewFile();
                FileWriter fw = new FileWriter(filePath);
                fw.write("DATE,PREV_ROLLING,EXPENSE,CASH_BAL,BONUS,CASH_BAL_AFTER_BONUS,BUSINESS_TODAY,ADDITIONAL_ROLL_BOX,ADDITIONAL_ROLL_TS,ROLL_TOMORROW,PREV_BOX_DEFICIT,SAVINGS_TO_REDUCE_BOX_DEFICIT,BOX_DEFICIT_TODAY,ELECTRICITY,SALARY,PREV_BOX_SAVINGS,BOX_SAVINGS_TODAY,BOX_AMT_TO_TS,URBAN_COLLECTION,PREV_TOTAL_SAVINGS,SAVINGS_TODAY,TOTAL_SAVINGS_TODAY,TRANSFERRED_TS_TO_BANK,EMP1_SALARY,EMP2_SALARY,EMP1_BONUS,EMP2_BONUS,EMP3_BONUS,ADD_WITHDRAWL_TS\n");
                fw.write("20000101,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0\n");
                fw.close();
                msg = "created new file";
            } else {
                msg = "already exists";
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        System.out.println("-----> "+msg);
        return msg;
    }

    //Read File
    public static List<String> readAllLinesFromFile(String filePath) throws Exception {
        List<String> linesList = new ArrayList<>();
        try {
            BufferedReader in = new BufferedReader(new FileReader(new File(filePath)));
            String currentLine;
            while((currentLine=in.readLine())!=null) {
                linesList.add(currentLine);
            }
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return linesList;
    }

    public static String readFirstLineFromFile(String filePath) throws Exception {
        String headerStr = null;
        BufferedReader in = new BufferedReader(new FileReader(new File(filePath)));
        headerStr = in.readLine();
        in.close();
        return headerStr;
    }

    //Write File
    public static void writeFile(String filePath, List<String> lines) throws Exception {
        FileWriter fw = new FileWriter(filePath);
        for(String line:lines) {
            fw.write(line+"\n");
        }
        fw.close();
    }

    public static void deleteFile(String filePath) {
        try {
            File file = new File(filePath);
            if(file.exists()) {
                file.delete();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
