package com.example.navigatorapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.example.navigatorapp.other.CommonMethods;
import com.example.navigatorapp.other.ReadWriteStoreSales;
import com.example.navigatorapp.other.Report;
import com.example.navigatorapp.other.Validations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Activity06_Create_Report extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    Spinner reportDD;
    Button reportSubmitBtn;
    CheckBox expenseTodayCb,cashBalanceCb,savingTodayCb,prevRollingCb;
    CheckBox addRollFromBoxCb,addRollFromTSCb,urbanCb,rollTomorrowCb;
    CheckBox boxSavingsCb,totalSavingsCb,businessTodayCb;
    String reportOption;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity06__create_report);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.getMenu().getItem(3).setChecked(true);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        initElements();
        reportSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    getValues();
//                    Toast.makeText(Activity06_Create_Report.this, "Clicked on generate report.", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Activity06_Create_Report.this, Activity07_View_Report.class);
                    intent.putExtra("no_of_records", getNoOfLatestRecordsRequired());
                    intent.putStringArrayListExtra("req_fields_list", getReqFields());
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        navToActivity(Activity06_Create_Report.this, Activity01_Home.class);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
            navToActivity(Activity06_Create_Report.this, Activity01_Home.class);
        } else if (id == R.id.nav_create) {
            navToActivity(Activity06_Create_Report.this, Activity02_Create.class);
        } else if (id == R.id.nav_search_sales) {
            navToActivity(Activity06_Create_Report.this, Activity04_Search_Sales.class);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void navToActivity(Context context, Class<?> cls) {
        Intent intent = new Intent(context, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    private void initElements() {
        reportDD = (Spinner) findViewById(R.id.report_dropdown);
        reportSubmitBtn = (Button) findViewById(R.id.generateReport_Btn);
        expenseTodayCb = (CheckBox) findViewById(R.id.expenseToday_cb);
        cashBalanceCb = (CheckBox) findViewById(R.id.cashbal_cb);
        savingTodayCb = (CheckBox) findViewById(R.id.savingsToday_cb);
        prevRollingCb = (CheckBox) findViewById(R.id.prevRolling_cb);
        addRollFromBoxCb = (CheckBox) findViewById(R.id.addRollFromBox_cb);
        addRollFromTSCb = (CheckBox) findViewById(R.id.addRollFromTS_cb);
        urbanCb = (CheckBox) findViewById(R.id.urban_cb);
        rollTomorrowCb = (CheckBox) findViewById(R.id.rollTomorrow_cb);
        boxSavingsCb = (CheckBox) findViewById(R.id.boxSavings_cb);
        totalSavingsCb = (CheckBox) findViewById(R.id.totalSavings_cb);
        businessTodayCb = (CheckBox) findViewById(R.id.businessToday_cb);
    }

    private void getValues() {
         reportOption = reportDD.getSelectedItem().toString();
    }

    private int getNoOfLatestRecordsRequired() {
        System.out.println("reportOption "+reportOption);
        Matcher matcher = Pattern.compile("(Recent )(\\d+)( Sales)").matcher(reportOption);
        matcher.matches();
        return Integer.parseInt(matcher.group(2));
    }

    private ArrayList<String> getReqFields() {
        ArrayList<String> reqFields = new ArrayList<>();
        if(expenseTodayCb.isChecked()) {
            reqFields.add("EXPENSE");
        }
        if(cashBalanceCb.isChecked()) {
            reqFields.add("CASH_BAL");
        }
        if(savingTodayCb.isChecked()) {
            reqFields.add("SAVINGS_TODAY");
        }
        if(businessTodayCb.isChecked()) {
            reqFields.add("BUSINESS_TODAY");
        }
        if(prevRollingCb.isChecked()) {
            reqFields.add("PREV_ROLLING");
        }
        if(addRollFromBoxCb.isChecked()) {
            reqFields.add("ADDITIONAL_ROLL_BOX");
        }
        if(addRollFromTSCb.isChecked()) {
            reqFields.add("ADDITIONAL_ROLL_TS");
        }
        if(urbanCb.isChecked()) {
            reqFields.add("URBAN_COLLECTION");
        }
        if(rollTomorrowCb.isChecked()) {
            reqFields.add("ROLL_TOMORROW");
        }
        if(boxSavingsCb.isChecked()) {
            reqFields.add("BOX_SAVINGS_TODAY");
        }
        if(totalSavingsCb.isChecked()) {
            reqFields.add("TOTAL_SAVINGS_TODAY");
        }
        System.out.println("reqFieldsList in act6: "+reqFields);
        return reqFields;
    }

}
