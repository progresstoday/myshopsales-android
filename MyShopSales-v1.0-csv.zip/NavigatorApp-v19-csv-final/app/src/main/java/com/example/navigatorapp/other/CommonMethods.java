package com.example.navigatorapp.other;

import java.util.HashMap;

public class CommonMethods {

	public static String filePath = null;

	public static HashMap<String, String> readPrevTestData2(String today) {
		HashMap<String,String> lastSaleMap_Key_Name = null;
		try {
			lastSaleMap_Key_Name =  ReadWriteStoreSales.getLastSaleMap_Key_Name(filePath, today);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lastSaleMap_Key_Name;
	}

	public static void setTestData(HashMap<String,String> dataMap) {
		try {
			System.out.println("-----> in setting sales for date: "+dataMap.get("DATE"));
			ReadWriteStoreSales.saveSalesToday(filePath, dataMap.get("DATE"), dataMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
