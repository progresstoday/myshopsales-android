package com.example.navigatorapp.other;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.navigatorapp.R;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Report {
    static int dateRowIndex = 0;
    static Context ct;

    public static void createHeaderRow(Context ct1, TableLayout table, HashMap<Integer, String> headerMap, Resources res) {
        ct = ct1;
        int noOfFields = headerMap.size();
        TableRow hrow = new TableRow(ct);
        hrow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.WRAP_CONTENT));
        hrow.setWeightSum(noOfFields);
        hrow.setBackgroundResource(R.drawable.row_border);
        addHeaderTextView(ct,hrow,headerMap,res);
        table.addView(hrow);
    }

    public static void createValueRows(Context ct1, TableLayout table, List<HashMap<Integer, String>> listOfMaps) {
        ct = ct1;
        int noOfFields = listOfMaps.get(0).size();
        for(int i=0; i<listOfMaps.size(); i++) {
            HashMap<Integer, String> map = new HashMap<>(listOfMaps.get(i));
            TableRow row = new TableRow(ct);
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.WRAP_CONTENT));
            row.setWeightSum(noOfFields);
            if(i%2==0) {
                row.setBackgroundResource(R.drawable.row_border1);
            } else {
                row.setBackgroundResource(R.drawable.row_border2);
            }
            addValueTextView(ct,row,map);
            table.addView(row);
            map.clear();

        }
    }

    static void addHeaderTextView(Context ct1, TableRow row, HashMap<Integer, String> headerMap, Resources res) {
        ct = ct1;
        Set<Integer> keys = headerMap.keySet();
        for(int i = 0;i<headerMap.size(); i++) {
            if("DATE".equalsIgnoreCase(headerMap.get(i))) {
                dateRowIndex = i;
                System.out.println("dateRowIndex "+dateRowIndex);
                break;
            }
        }

        TextView hcol4 = new TextView(ct);
        hcol4.setText(getReqFieldStrId(res, headerMap.get(dateRowIndex)));
        hcol4.setTextColor(Color.parseColor("#FFFFFF"));
        hcol4.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1f));
        hcol4.setPadding(50, 50, 50, 50);
        row.addView(hcol4);

        for(int key: headerMap.keySet()) {
            if(key!=dateRowIndex) {
                TextView hcol3 = new TextView(ct);
                System.out.println(getReqFieldStrId(res, headerMap.get(key)) + " MAHESH");
                hcol3.setText(getReqFieldStrId(res, headerMap.get(key)));
                hcol3.setTextColor(Color.parseColor("#FFFFFF"));
                hcol3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1f));
                hcol3.setPadding(50, 50, 50, 50);
                row.addView(hcol3);
            }
        }

    }

    public static String getReqFieldStrId(Resources res, String str) {
        System.out.println("str xyz "+str);
        String str2 = "";
        if("DATE".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.date);
        } else if("EXPENSE".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.expense_today);
        } else if("CASH_BAL".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.cash_balance);
        } else if("SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.savings_today);
        } else if("BUSINESS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.business_today);
        } else if("PREV_ROLLING".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.previous_rolling);
        } else if("ADDITIONAL_ROLL_BOX".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.additional_rolling_from_box);
        } else if("ADDITIONAL_ROLL_TS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.additional_rolling_from_ts);
        } else if("URBAN_COLLECTION".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.urban_collection);
        } else if("ROLL_TOMORROW".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.rolling_tomorrow);
        } else if("BOX_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.box_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("BONUS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else {
            str2 = str;
        }
        return str2;
    }

    static void addValueTextView(Context ct1, TableRow row, HashMap<Integer, String> valueMap) {
        ct = ct1;
        String val1 = valueMap.get(dateRowIndex);
        val1 = val1.substring(6,8)+"-"+val1.substring(4,6)+"-"+val1.substring(0,4);
        TextView hcol4 = new TextView(ct);
        hcol4.setText(val1);
        hcol4.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.WRAP_CONTENT,1f));
        hcol4.setPadding(50,50,50,50);
        row.addView(hcol4);

        for(int key:valueMap.keySet()) {
            if(key!=dateRowIndex) {
                String val = valueMap.get(key);
                TextView hcol3 = new TextView(ct);
                hcol3.setText(val);
                hcol3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.WRAP_CONTENT,1f));
                hcol3.setPadding(50,50,50,50);
                row.addView(hcol3);
            }
        }
    }
}
