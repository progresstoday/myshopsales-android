package com.example.navigatorapp.other;

import android.app.Activity;
import android.widget.EditText;
import android.widget.Spinner;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.example.navigatorapp.R;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Validations {
    private static int resultantCashBalance = 0;

    public static void dateValidation(AwesomeValidation awesomeValidation, EditText dateObj, String date) throws Exception {
        System.out.println("date inside datevalidation "+date);
        boolean isValid = false;
        String date_errorMsg = null;
        if(date==null || date.equals("") || date.length()!=8) {
            date_errorMsg = "Enter Date.";
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            Date currentDate = sdf.parse(date);
            if (!date.equals(sdf.format(currentDate))) {
                currentDate = null;
            }
            if (currentDate == null) {
                date_errorMsg = "Enter Valid Date.";
            } else {
                if(currentDate.after(new Date())) {
                    date_errorMsg = "Should be <= Today's Date.";
                } else {
                    isValid = true;
                }
            }
        }
        String regEx = isValid ? "[0-9]{2}-[0-9]{2}-[0-9]{4}":"INVALID";
        System.out.println("date2 "+date+" "+regEx);
        awesomeValidation.addValidation(dateObj, regEx, date_errorMsg);
    }

    public static void expenseTodayValidation(AwesomeValidation awesomeValidation, EditText obj, String val) throws Exception {
        String errMsg = null;
        boolean isValid = true;
        if(val==null || val.equals("")) {
            isValid = false;
            errMsg = "Enter Expense Today Amount.";
        }
        String regEx = isValid ? "[1-9][0-9]{0,9}":"INVALID";
        awesomeValidation.addValidation(obj, regEx, errMsg);
    }

    static int cb = 0;
    public static void cashBalValidation(AwesomeValidation awesomeValidation, EditText obj, String val) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(val==null || val.equals("")) {
            errMsg = "Enter Cash Balance.";
        } else {
            isValid = true;
            resultantCashBalance = Integer.parseInt(val);
            cb = resultantCashBalance;
            System.out.println(cb+" cb1");
        }
        String regEx = isValid ? "[1-9][0-9]{0,9}":"INVALID";
        awesomeValidation.addValidation(obj, regEx, errMsg);
    }

    static int savings = 0;
    public static void savingsValidation(AwesomeValidation awesomeValidation, EditText obj, String val) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(val==null || val.equals("")) {
            errMsg = "Enter Cash Balance";
        } else {
            int savingsToday = Integer.parseInt(val);
            if(savingsToday>resultantCashBalance) {
                errMsg = "Enter Cash Balance <= "+resultantCashBalance;
            } else {
                isValid = true;
                savings = savingsToday;
                System.out.println(savings+" savings1");
                resultantCashBalance = resultantCashBalance - savingsToday;
            }
        }
        String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
        awesomeValidation.addValidation(obj, regEx, errMsg);
    }

    static int rollTomorrow = 0;
    public static void rollingTomorrowValidation(AwesomeValidation awesomeValidation, EditText obj, String val) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(val==null || val.equals("")) {
            errMsg = "Enter Roll Amount.";
        } else {
            int rollingTomorrowToday = Integer.parseInt(val);
            if(rollingTomorrowToday>resultantCashBalance && resultantCashBalance>0) {
                errMsg = "Enter Rolling Tomorrow <= "+resultantCashBalance;
            } else {
                isValid = true;
                rollTomorrow = rollingTomorrowToday;
                System.out.println(rollTomorrow+" rollTomorrow1");
                resultantCashBalance = resultantCashBalance - rollingTomorrowToday;
            }
        }
        String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
        awesomeValidation.addValidation(obj, regEx, errMsg);
    }

    static int savToRemoveBoxDef = 0;
    public static void savingsToRemoveBoxDeficitValidation(AwesomeValidation awesomeValidation, EditText obj, String val) throws Exception {
        if(!(val==null || val.equals(""))) {
            String errMsg = null;
            boolean isValid = false;
            int savingsToRemoveBoxDeficit = Integer.parseInt(val);
            if(savingsToRemoveBoxDeficit>resultantCashBalance && resultantCashBalance>0) {
                errMsg = "Amount <= "+resultantCashBalance;
            } else {
                isValid = true;
                savToRemoveBoxDef = savingsToRemoveBoxDeficit;
                System.out.println(savToRemoveBoxDef+" savToRemoveBoxDef1");
                resultantCashBalance = resultantCashBalance - savingsToRemoveBoxDeficit;
            }
            String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
            awesomeValidation.addValidation(obj, regEx, errMsg);
        }

    }

    static int bonus1 = 0;
    public static void bonusValidation(AwesomeValidation awesomeValidation, EditText obj, String val) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(!(val==null || val.equals(""))) {
            int bonus = Integer.parseInt(val);
            if(bonus>resultantCashBalance && resultantCashBalance>0) {
                errMsg = "Amount should be "+resultantCashBalance;
            } else {
                isValid = true;
                bonus1 = bonus;
                System.out.println(bonus1+" bonus1");
                resultantCashBalance = resultantCashBalance - bonus;
            }
            String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
            awesomeValidation.addValidation(obj, regEx, errMsg);
        }

    }

    public static void addRollingFromBoxValidation(AwesomeValidation awesomeValidation, EditText obj, String val, int boxSavings) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(!(val==null || val.equals(""))) {
            int valInt = Integer.parseInt(val);
            if(valInt<=boxSavings) {
                isValid = true;
            } else {
                errMsg = "Amount should be <= "+boxSavings;
            }
            String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
            awesomeValidation.addValidation(obj, regEx, errMsg);
        }

    }

    public static void addRollingFromTSValidation(AwesomeValidation awesomeValidation, EditText obj, String val, int totalSavings) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(!(val==null || val.equals(""))) {
            int valInt = Integer.parseInt(val);
            if(valInt<=totalSavings) {
                isValid = true;
            } else {
                errMsg = "Amount should be <= "+totalSavings;
            }
            String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
            awesomeValidation.addValidation(obj, regEx, errMsg);
        }

    }

    public static void urbanCollectionValidation(AwesomeValidation awesomeValidation, EditText obj, String val, int totalSavings) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(!(val==null || val.equals(""))) {
            int valInt = Integer.parseInt(val);
            if(valInt<=totalSavings) {
                isValid = true;
            } else {
                errMsg = "Amount should be <= "+totalSavings;
            }
            String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
            awesomeValidation.addValidation(obj, regEx, errMsg);
        }

    }

    public static void electricityValidation(AwesomeValidation awesomeValidation, EditText obj, String val, int boxSavings) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(!(val==null || val.equals(""))) {
            int valInt = Integer.parseInt(val);
            if(valInt<=boxSavings) {
                isValid = true;
            } else {
                errMsg = "Amount should be <= "+boxSavings;
            }
            String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
            awesomeValidation.addValidation(obj, regEx, errMsg);
        }

    }

    public static void salaryValidation(AwesomeValidation awesomeValidation, EditText obj, String val, int boxSavings) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(!(val==null || val.equals(""))) {
            int valInt = Integer.parseInt(val);
            if(valInt<=boxSavings) {
                isValid = true;
            } else {
                errMsg = "Amount should be <= "+boxSavings;
            }
            String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
            awesomeValidation.addValidation(obj, regEx, errMsg);
        }

    }

    public static void totSavAmtToTSValidation(AwesomeValidation awesomeValidation, EditText obj, String val, int totalSavings) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        if(!(val==null || val.equals(""))) {
            int valInt = Integer.parseInt(val);
            if(valInt<=totalSavings) {
                isValid = true;
            } else {
                errMsg = "Amount should be <= "+totalSavings;
            }
            String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
            awesomeValidation.addValidation(obj, regEx, errMsg);
        }

    }

    public static void resultantCashBalanceValidation(AwesomeValidation awesomeValidation, EditText obj) throws Exception {
        String errMsg = null;
        boolean isValid = false;
        int res1 = cb-rollTomorrow-savings-savToRemoveBoxDef-bonus1;
        System.out.println(res1+" resultantCashBalance");
        if(res1==0) {
            isValid = true;
        } else {
            errMsg = "put "+(res1+rollTomorrow);
        }
        String regEx = isValid ? "[0-9][0-9]{0,9}":"INVALID";
        awesomeValidation.addValidation(obj, regEx, errMsg);
    }
}