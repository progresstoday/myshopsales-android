package com.example.navigatorapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;

import com.example.navigatorapp.other.CommonMethods;
import com.example.navigatorapp.other.ReadWriteStoreSales;
import com.example.navigatorapp.other.Report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Activity07_View_Report extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    int noOfRecords=5;
    ArrayList<String> reqFieldsList;
    String fileName = "store";
    String filePath;
    Context ct = this;
    TableLayout report_table;
    HashMap<Integer, String> headerMap = new HashMap<>();
    List<HashMap<Integer, String>> valuesListOfMaps = new ArrayList<>();
    HashMap<Integer, String> effHeaderMap = new HashMap<>();
    List<HashMap<Integer, String>> effValuesListOfMaps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity07__view_report);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        noOfRecords = (int)getIntent().getSerializableExtra("no_of_records");
        reqFieldsList = (ArrayList<String>) getIntent().getSerializableExtra("req_fields_list");
        System.out.println("noOfRecords in act7: "+noOfRecords);
        System.out.println("reqFieldsList in act7: "+reqFieldsList);
        initFilePath();
        initElements();
        try {
            getValues();
            getEffectiveValues();
            createTableReport();
        } catch (Exception e) {
            e.printStackTrace();
        }

        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        navToActivity(Activity07_View_Report.this, Activity06_Create_Report.class);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
            navToActivity(Activity07_View_Report.this, Activity01_Home.class);
        } else if (id == R.id.nav_create) {
            navToActivity(Activity07_View_Report.this, Activity02_Create.class);
        } else if (id == R.id.nav_search_sales) {
            navToActivity(Activity07_View_Report.this, Activity04_Search_Sales.class);
        } else if (id == R.id.nav_custom_search) {
            navToActivity(Activity07_View_Report.this, Activity06_Create_Report.class);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void navToActivity(Context context, Class<?> cls) {
        Intent intent = new Intent(context, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    private void initFilePath() {
        filePath = getFilesDir().getPath() + "/"+fileName+".csv";
        CommonMethods.filePath = filePath;
    }

    private void initElements() {
        report_table = (TableLayout) findViewById(R.id.report_table);
    }

    private void getValues() throws Exception {
        headerMap = ReadWriteStoreSales.getHeaderMap_Key_Index(filePath);
        System.out.println("headerMap2: "+headerMap);

        valuesListOfMaps = ReadWriteStoreSales.getSalesListOfMaps(filePath, noOfRecords);

        System.out.println("valuesListOfMaps: "+valuesListOfMaps);
        System.out.println("valuesListOfMaps2: "+valuesListOfMaps.size());
        for(HashMap<Integer, String> map1: valuesListOfMaps) {
            System.out.println("valuesListOfMaps map3: "+map1);
        }
    }

    private void getEffectiveValues() throws Exception {
        if(reqFieldsList.isEmpty()) {
            effHeaderMap = headerMap;
            effValuesListOfMaps = valuesListOfMaps;
        } else {
            reqFieldsList.add("DATE");
            System.out.println("headerMap "+headerMap);
            effHeaderMap = ReadWriteStoreSales.effectiveHeaderMap(headerMap,reqFieldsList);
            System.out.println("effHeaderMap "+effHeaderMap);
            System.out.println("valuesListOfMaps "+valuesListOfMaps);
            effValuesListOfMaps = ReadWriteStoreSales.effectiveListOfMap(valuesListOfMaps,headerMap,reqFieldsList);
            System.out.println("effValuesListOfMaps "+effValuesListOfMaps);
        }
    }

    private void createTableReport() {
        Report.createHeaderRow(ct,report_table,effHeaderMap,getResources());
        Report.createValueRows(ct,report_table,effValuesListOfMaps);
    }
}