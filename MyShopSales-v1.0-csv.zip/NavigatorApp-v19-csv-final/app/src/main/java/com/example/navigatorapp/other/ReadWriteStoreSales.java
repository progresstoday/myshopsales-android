package com.example.navigatorapp.other;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ReadWriteStoreSales {

	//Get Header Map
	public static HashMap<Integer, String> getHeaderMap_Key_Index(String filePath) throws Exception {
		HashMap<Integer,String> headerMap_Key_Index = new HashMap<Integer,String>();
		String[] headerArr = ReadWriteFile.readFirstLineFromFile(filePath).split(",");
		for (int i = 0; i < headerArr.length; i++) {
			headerMap_Key_Index.put(i,headerArr[i]);
		}
		return headerMap_Key_Index;
	}

	public static HashMap<String,Integer> getHeaderMap_Key_Name(String filePath) throws Exception {
		HashMap<String,Integer> headerMap_Key_Name = new HashMap<>();
		String[] headerArr = ReadWriteFile.readFirstLineFromFile(filePath).split(",");
		for (int i = 0; i < headerArr.length; i++) {
			headerMap_Key_Name.put(headerArr[i],i);
		}
		return headerMap_Key_Name;
	}
	
	//Read Previous Sales
	public static HashMap<String, String> getLastSaleMap_Key_Name(String filePath, String today) throws Exception {
		HashMap<String,String> lastSaleMap_Key_Name = new HashMap<String,String>();
		HashMap<Integer,String> headerMap_Key_Index = getHeaderMap_Key_Index(filePath);
		String[] dataArr = getLastSaleStr(filePath, today).split(",");
		for (int i = 0; i < dataArr.length; i++) {
			lastSaleMap_Key_Name.put(headerMap_Key_Index.get(i),dataArr[i]);
		}
		return lastSaleMap_Key_Name;
	}
	
	public static String getLastSaleStr(String filePath, String today) throws Exception {
		String lastSale = null;
		try {
			List<String> salesRecord = ReadWriteFile.readAllLinesFromFile(filePath);
			System.out.println("-----> in total records "+salesRecord.size());
			System.out.println("-----> in total records "+salesRecord);
			int lastSaleIndex = salesRecord.size()-1;
			lastSale = salesRecord.get(lastSaleIndex);
			System.out.println("-----> in lastSale1 "+lastSale);
			System.out.println("-----> in lastSale1 "+today);
			System.out.println("-----> in lastSale "+lastSale.contains(today));
			if(lastSale.contains(today)) {
				lastSale = salesRecord.get(lastSaleIndex-1);
				System.out.println("-----> in lastSale2 "+lastSale);
			}
			System.out.println("-----> in lastSale "+lastSale);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lastSale;
	}
	
	//-----------Saving..
	public static void saveSalesToday(String filePath, String today, HashMap<String, String> todaySalesMap_Key_Name) throws Exception {
		String nextLine = getTodaySalesStr(filePath, today, todaySalesMap_Key_Name);
		List<String> lines = ReadWriteFile.readAllLinesFromFile(filePath);
		int lastLineNo = lines.size()-1;
		String lastLine = lines.get(lastLineNo);
		System.out.println("-----> setting sales last line check "+lastLine);
		System.out.println("-----> setting sales last line checked "+lastLine.contains(today));
		if(lastLine.contains(today)) {
			System.out.println("-----> override before "+lines.size());
			System.out.println("-----> override before "+lines.get(lastLineNo));
			lines.remove(lastLineNo);
			System.out.println("-----> override before but after removed "+lines.size());
			lines.add(lastLineNo, nextLine);
			System.out.println("-----> override after "+lines.get(lastLineNo));
			System.out.println("-----> override after "+lines.size());
		} else {
			System.out.println("-----> override before1 "+lines.size());
			System.out.println("-----> override before1 "+lines.get(lastLineNo));
			lines.add(lastLineNo+1, nextLine);
			System.out.println("-----> override after1 "+lines.get(lastLineNo));
			System.out.println("-----> override after12 "+lines.get(lastLineNo+1));
			System.out.println("-----> override after1 "+lines.size());
		}
//		Collections.sort(lines);
		ReadWriteFile.writeFile(filePath, lines);
	}
	
	public static String getTodaySalesStr(String filePath, String today, HashMap<String, String> todaySalesMap_Key_Name) throws Exception {
		StringBuffer todaySalesStr = new StringBuffer(today);
		HashMap<Integer,String> headerMap_Key_Index = getHeaderMap_Key_Index(filePath);
		for (int i = 1; i < headerMap_Key_Index.size(); i++) {
			todaySalesStr.append(","+todaySalesMap_Key_Name.get(headerMap_Key_Index.get(i)));
		}
		return todaySalesStr.toString();
	}

	public static HashMap<Integer, String> getSaleMap_Key_Index(String saleRecord) throws Exception {
		HashMap<Integer,String> saleMap_Key_Index = new HashMap<Integer, String>();
		String[] dataArr = saleRecord.split(",");
		for (int i = 0; i < dataArr.length; i++) {
			saleMap_Key_Index.put(i,dataArr[i]);
		}
		return saleMap_Key_Index;
	}

	public static List<HashMap<Integer, String>> getSalesListOfMaps(String filePath, int noOfRecordsRequired) throws Exception {
		List<HashMap<Integer, String>> listOfMap = new ArrayList<>();

		List<String> salesRecord = ReadWriteFile.readAllLinesFromFile(filePath);
		int totalSales = salesRecord.size();
		int count = noOfRecordsRequired;
		System.out.println("totalSales avaiable: "+totalSales);
		for(int i=totalSales-1; i>0 && count-->0; i--) {
			System.out.println("sale avaiable: "+i);
			String saleRecord = salesRecord.get(i);
			System.out.println((count+1)+": "+saleRecord);
			listOfMap.add(getSaleMap_Key_Index(saleRecord));
		}
		System.out.println("list: "+listOfMap);
		System.out.println("list2: "+listOfMap.size());
		for(HashMap<Integer, String> map1: listOfMap) {
			System.out.println("list map3: "+map1);
		}
		return listOfMap;
	}

	public static HashMap<Integer, String> effectiveHeaderMap(HashMap<Integer, String> headerMap, List<String> reqFieldsList) {
        HashMap<Integer,String> effHeaderMap = new HashMap<>();
        for(int key:headerMap.keySet()) {
            System.out.println(headerMap.get(key));
            if(reqFieldsList.contains(headerMap.get(key))) {
                effHeaderMap.put(key,headerMap.get(key));
            }
        }
        System.out.println(effHeaderMap);
        return effHeaderMap;
    }

    public static List<HashMap<Integer,String>> effectiveListOfMap(List<HashMap<Integer,String>> listOfMap,HashMap<Integer, String> headerMap,List<String> reqFieldsList) {
        List<HashMap<Integer,String>> effListOfMap = new ArrayList<>();
        for(HashMap<Integer,String> map:listOfMap) {
            HashMap<Integer,String> effValMap = new HashMap<>();
            for(int key:map.keySet()) {
                System.out.println(map.get(key));
                if(reqFieldsList.contains(headerMap.get(key))) {
                    effValMap.put(key,map.get(key));
                }
            }
            effListOfMap.add(effValMap);
        }
        System.out.println(effListOfMap);
        return effListOfMap;
    }

}
