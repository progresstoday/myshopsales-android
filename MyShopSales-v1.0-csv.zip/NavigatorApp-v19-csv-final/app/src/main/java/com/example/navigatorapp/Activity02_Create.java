package com.example.navigatorapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.example.navigatorapp.other.CommonMethods;
import com.example.navigatorapp.other.MyDatePicker;
import com.example.navigatorapp.other.ReadWriteFile;
import com.example.navigatorapp.other.Store;
import com.example.navigatorapp.other.Validations;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class Activity02_Create extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    final Calendar myCal = Calendar.getInstance();
    Context ct = this;
    private AwesomeValidation awesomeValidation;

    //Elements
    EditText dateTextObj,expenseTodayObj,cashBalObj,savingsTodayObj,rollTomorrowObj,addRollFromBoxObj,addRollFromTSObj;
    EditText savToRemoveBoxDefObj,urbanCollObj,electricityObj,salaryObj,bonusObj,totSavToBankObj;
    EditText prevRollingObj, prevBoxDefObj, prevBoxSavingsObj, prevTSObj;
    EditText emp1SalaryObj, emp2SalaryObj, emp1BonusObj, emp2BonusObj, emp3BonusObj, addWithdrawlFromTSObj;
    CheckBox tranBoxAmtToTSObj,overridePrevSalesObj;
    Button submit,resetBtn;

    //Values
    String dateVal, expenseTodayVal, cashBalVal, savingsTodayVal, rollTomorrowVal;
    String addRollFromBoxVal, addRollFromTSVal, savToRemoveBoxDefVal, urbanVal;
    String electricityVal, salaryVal, bonusVal, totalSavingsToBankVal;
    String prevRollingVal, prevBoxDefVal, prevBoxSavingsVal, prevTSVal;
    String emp1SalaryVal, emp2SalaryVal, emp1BonusVal, emp2BonusVal, emp3BonusVal, addWithdrawlFromTSVal;
    boolean isOverridePrevSalesVal = false,transfBoxAmtToTSVal = false;
    HashMap<String, String> prevSalesDataMap = new HashMap<String, String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity02_create);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.getMenu().getItem(1).setChecked(true);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        //Initialization
        initPrevElements();
        initElements();
        setDefaultDate();
        initDatePicker();
        getPrevValues();
        prevValidations();

        try {
            overridePrevSalesObj.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getPrevValues();
                    prevValidations();
                    Toast.makeText(Activity02_Create.this, "Previous data values are added.", Toast.LENGTH_LONG).show();
                    System.out.println("Previous........");
                    System.out.println(prevTSVal);
                    System.out.println(prevBoxSavingsVal);
                    System.out.println("Previous checked done........");
                }
            });
            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        getValues();
                        //-----
                        System.out.println("------> Submit clicked........");
                        getPrevValues();
                        prevValidations();
                        //-----

                        System.out.println("isDataValid"+isDataValid());
                        if (isDataValid()) {
                            Intent intent = new Intent(Activity02_Create.this, Activity03_SalesToday.class);
                            HashMap<String, String> salesToday = getSalesToday();
                            intent.putExtra("salesToday", salesToday);
                            startActivity(intent);
                        }
                    } catch(Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            resetBtn.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Activity02_Create.this,Activity02_Create.class);
                    startActivity(intent);
                }
            });
        } catch(Exception e) {
            e.printStackTrace();
        }

        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Activity02_Create.this, Activity01_Home.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void navToActivity(Context context, Class<?> cls) {
        Intent intent = new Intent(context, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            navToActivity(Activity02_Create.this, Activity01_Home.class);
        } else if (id == R.id.nav_search_sales) {
            navToActivity(Activity02_Create.this, Activity04_Search_Sales.class);
        } else if (id == R.id.nav_custom_search) {
            navToActivity(Activity02_Create.this, Activity06_Create_Report.class);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void initPrevElements() {
        prevBoxDefObj = (EditText) findViewById(R.id.prevBoxDeficit_editText);
        prevBoxSavingsObj = (EditText) findViewById(R.id.prevBoxSavings_editText);
        prevRollingObj = (EditText) findViewById(R.id.prevRolling_editText);
        prevTSObj = (EditText) findViewById(R.id.prevTS_editText);
        overridePrevSalesObj = (CheckBox) findViewById(R.id.overridePrevSales_checkBox);
    }

    private void initElements() {
        dateTextObj = (EditText) findViewById(R.id.date_editText);
        expenseTodayObj = (EditText) findViewById(R.id.expenseToday_editText);
        cashBalObj = (EditText) findViewById(R.id.cashBal_editText);
        savingsTodayObj = (EditText) findViewById(R.id.savingsToday_editText);
        rollTomorrowObj = (EditText) findViewById(R.id.rollTomorrow_editText);
        addRollFromBoxObj = (EditText) findViewById(R.id.addRollFromBox_editText);
        addRollFromTSObj = (EditText) findViewById(R.id.addRollFromTS_editText);
        savToRemoveBoxDefObj = (EditText) findViewById(R.id.saveToRemoveBoxDef_editText);
        urbanCollObj = (EditText) findViewById(R.id.urbanColl_editText);
        electricityObj = (EditText) findViewById(R.id.electricity_editText);
        salaryObj = (EditText) findViewById(R.id.salary_editText);
        bonusObj = (EditText) findViewById(R.id.bonus_editText);
        totSavToBankObj = (EditText) findViewById(R.id.transferTSToBank_editText);
        tranBoxAmtToTSObj = (CheckBox) findViewById(R.id.transfBoxAmtToTS_checkBox);
        submit = (Button)findViewById(R.id.submit_button);
        resetBtn = (Button)findViewById(R.id.reset_button);
        emp1SalaryObj = (EditText) findViewById(R.id.emp1Salary_editTxt);
        emp2SalaryObj = (EditText) findViewById(R.id.emp2Salary_editTxt);
        emp1BonusObj = (EditText) findViewById(R.id.emp1Bonus_editTxt);
        emp2BonusObj = (EditText) findViewById(R.id.emp2Bonus_editTxt);
        emp3BonusObj = (EditText) findViewById(R.id.emp3Bonus_editTxt);
        addWithdrawlFromTSObj = (EditText) findViewById(R.id.addWithdrawalFromTS_editTxt);
    }

    private void initDatePicker() {
        MyDatePicker.datePicker(ct,dateTextObj);
    }

    private void getPrevValues() {
        prevBoxDefVal = prevBoxDefObj.getText().toString();
        prevBoxSavingsVal = prevBoxSavingsObj.getText().toString();
        prevRollingVal = prevRollingObj.getText().toString();
        prevTSVal = prevTSObj.getText().toString();
        isOverridePrevSalesVal = overridePrevSalesObj.isChecked();
    }

    private void getValues() {
        dateVal = dateTextObj.getText().toString();
        if(!(dateVal==null || dateVal.equals("") || dateVal.isEmpty())) {
            dateVal=dateVal.substring(6,10)+dateVal.substring(3,5)+dateVal.substring(0,2);
        }
        expenseTodayVal = expenseTodayObj.getText().toString();
        cashBalVal = cashBalObj.getText().toString();
        savingsTodayVal = savingsTodayObj.getText().toString();
        rollTomorrowVal = rollTomorrowObj.getText().toString();
        addRollFromBoxVal = addRollFromBoxObj.getText().toString();
        addRollFromTSVal = addRollFromTSObj.getText().toString();
        savToRemoveBoxDefVal = savToRemoveBoxDefObj.getText().toString();
        urbanVal = urbanCollObj.getText().toString();
        electricityVal = electricityObj.getText().toString();
        salaryVal = salaryObj.getText().toString();
        bonusVal = bonusObj.getText().toString();
        totalSavingsToBankVal = totSavToBankObj.getText().toString();
        transfBoxAmtToTSVal = tranBoxAmtToTSObj.isChecked();

        emp1SalaryVal = prevBoxDefObj.getText().toString();
        emp2SalaryVal = prevBoxDefObj.getText().toString();
        emp1BonusVal = prevBoxDefObj.getText().toString();
        emp2BonusVal = prevBoxDefObj.getText().toString();
        emp3BonusVal = prevBoxDefObj.getText().toString();
        addWithdrawlFromTSVal = prevBoxDefObj.getText().toString();
    }

    private boolean isDataValid() throws Exception {
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        validation();
        return awesomeValidation.validate();
    }

    private boolean isDataValid2() throws Exception {
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        validation2();
        return awesomeValidation.validate();
    }

    private void prevValidations() {
        System.out.println("isOverridePrevSalesVal in preValidations: "+isOverridePrevSalesVal);
        if(isOverridePrevSalesVal) {
            prevSalesDataMap = new HashMap<>();
            prevSalesDataMap.put("TOTAL_SAVINGS_TODAY",""+toIntWithNullCheck(prevTSVal));
            prevSalesDataMap.put("BOX_SAVINGS_TODAY",""+toIntWithNullCheck(prevBoxSavingsVal));
            prevSalesDataMap.put("ROLL_TOMORROW",""+toIntWithNullCheck(prevRollingVal));
            prevSalesDataMap.put("BOX_DEFICIT_TODAY",""+toIntWithNullCheck(prevBoxDefVal));
        } else {
            String tempDate = dateVal;
            System.out.println("tempDate1 "+tempDate);
            if(tempDate==null || tempDate.equals("") || tempDate.isEmpty()) {
                tempDate = "18000101";
            }
            prevSalesDataMap.clear();
            prevSalesDataMap = CommonMethods.readPrevTestData2(tempDate);
        }
        System.out.println(prevSalesDataMap+" prevSalesDataMap");
    }

    private void validation() throws Exception {
        //Validations based on today's data
        Validations.dateValidation(awesomeValidation, dateTextObj, dateVal);
        Validations.expenseTodayValidation(awesomeValidation,expenseTodayObj,expenseTodayVal);
        Validations.cashBalValidation(awesomeValidation,cashBalObj,cashBalVal);
        Validations.savingsValidation(awesomeValidation,savingsTodayObj,savingsTodayVal);
        Validations.rollingTomorrowValidation(awesomeValidation,rollTomorrowObj,rollTomorrowVal);
        validation2();
    }

    private void validation2() throws Exception {
        Validations.savingsToRemoveBoxDeficitValidation(awesomeValidation,savToRemoveBoxDefObj,savToRemoveBoxDefVal);
        Validations.bonusValidation(awesomeValidation,bonusObj,bonusVal);
        int prevBoxSavingsInt = toIntWithNullCheck(prevSalesDataMap.get("BOX_SAVINGS_TODAY"));
        int prevTSInt = toIntWithNullCheck(prevSalesDataMap.get("TOTAL_SAVINGS_TODAY"));
        Validations.addRollingFromBoxValidation(awesomeValidation,addRollFromBoxObj,addRollFromBoxVal,prevBoxSavingsInt);
        Validations.addRollingFromTSValidation(awesomeValidation,addRollFromTSObj,addRollFromTSVal,prevTSInt);
        Validations.urbanCollectionValidation(awesomeValidation,urbanCollObj,urbanVal,prevTSInt);
        Validations.electricityValidation(awesomeValidation,electricityObj,electricityVal,prevBoxSavingsInt);
        Validations.salaryValidation(awesomeValidation,salaryObj,salaryVal,prevBoxSavingsInt);
        Validations.totSavAmtToTSValidation(awesomeValidation,totSavToBankObj,totalSavingsToBankVal,prevTSInt);
        Validations.resultantCashBalanceValidation(awesomeValidation,rollTomorrowObj);
    }

    public HashMap<String,String> getSalesToday() {
        System.out.println(prevSalesDataMap+" in get sales");
        Store store = new Store(dateVal,prevSalesDataMap);
        store.setExpenseToday(toIntWithNullCheck(expenseTodayVal));
        store.setCashBalanceToday(toIntWithNullCheck(cashBalVal));
        store.setSavingsToday(toIntWithNullCheck(savingsTodayVal));
        store.setRollingTomorrow(toIntWithNullCheck(rollTomorrowVal));
        store.setAddRollingFromBox(toIntWithNullCheck(addRollFromBoxVal));
        store.setAddRollingFromTotalSavings(toIntWithNullCheck(addRollFromTSVal));
        store.setSavingsToRemoveBoxDeficit(toIntWithNullCheck(savToRemoveBoxDefVal));
        store.setUrbanCollection(toIntWithNullCheck(urbanVal));
        store.setElectricity(toIntWithNullCheck(electricityVal));
        store.setSalary(toIntWithNullCheck(salaryVal));
        store.setBonus(toIntWithNullCheck(bonusVal));
        store.setAmountToMoveFromTotalSavingsToBank(toIntWithNullCheck(totalSavingsToBankVal));
        store.setBooleanMoveEntireBoxAmountToTotalSavings(transfBoxAmtToTSVal);

        store.setEmp1Salary(toIntWithNullCheck(emp1SalaryVal));
        store.setEmp2Salary(toIntWithNullCheck(emp2SalaryVal));
        store.setEmp1Bonus(toIntWithNullCheck(emp1BonusVal));
        store.setEmp2Bonus(toIntWithNullCheck(emp2BonusVal));
        store.setEmp3Bonus(toIntWithNullCheck(emp3BonusVal));
        store.setAddWithdrawlFromTS(toIntWithNullCheck(addWithdrawlFromTSVal));

        return store.generateSales();
    }

    private int toInt(String str) {
        return Integer.parseInt(str);
    }

    private int toIntWithNullCheck(String str) {
        if(str==null || str.equals("") || str.isEmpty()) {
            return 0;
        } else {
            return toInt(str);
        }
    }

    private void reset() {
        dateTextObj.setText("");
        expenseTodayObj.setText("");
        cashBalObj.setText("");
        savingsTodayObj.setText("");
        rollTomorrowObj.setText("");
        addRollFromBoxObj.setText("");
        addRollFromTSObj.setText("");
        savToRemoveBoxDefObj.setText("");
        urbanCollObj.setText("");
        electricityObj.setText("");
        salaryObj.setText("");
        bonusObj.setText("");
        totSavToBankObj.setText("");
        prevRollingObj.setText("");
        prevBoxDefObj.setText("");
        prevBoxSavingsObj.setText("");
        prevTSObj.setText("");
        emp1SalaryObj.setText("");
        emp2SalaryObj.setText("");
        emp1BonusObj.setText("");
        emp2BonusObj.setText("");
        emp3BonusObj.setText("");
        addWithdrawlFromTSObj.setText("");
        tranBoxAmtToTSObj.setChecked(false);
        overridePrevSalesObj.setChecked(false);
    }

    private void setDefaultDate() {
        dateTextObj.setText(new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
    }
}
