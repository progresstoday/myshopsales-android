package com.example.navigatorapp.other;

import com.example.navigatorapp.other.CommonMethods;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class SearchRecord {

    public static HashMap<String,String> getRecord(String reqDate) throws Exception {
        HashMap<String,String> reqMap = new HashMap<>();
        String str = getRecordStr(reqDate);
        System.out.println("-----> "+str);
        if(str==null || str.equals("")) {
            System.out.println("-----> No records"+str);
        } else {
            HashMap<Integer,String> headerMap_Key_Index = ReadWriteStoreSales.getHeaderMap_Key_Index(CommonMethods.filePath);
            String[] valuesArr = str.split(",");
            for (int i=0; i<valuesArr.length; i++) {
                System.out.println("-----> "+headerMap_Key_Index.get(i)+" --> "+valuesArr[i]);
                reqMap.put(headerMap_Key_Index.get(i),valuesArr[i]);
            }
        }
        System.out.println("-----> "+reqMap);
        return reqMap;
    }

    public static String getRecordStr(String reqDate) throws Exception {
        List<String> salesRecord = ReadWriteFile.readAllLinesFromFile(CommonMethods.filePath);
        System.out.println("-----> salesRecord "+salesRecord);
        int recordIndex = binarySearch(salesRecord, 1, salesRecord.size()-1, reqDate);
        System.out.println("-----> recordIndex: "+recordIndex);
        if(recordIndex>0) {
            return salesRecord.get(recordIndex);
        } else {
            return "";
        }
    }

    private static int binarySearch(List<String> list, int startIndex, int endIndex, String targetVal) {
        Collections.sort(list);
        int midIndex = (startIndex+endIndex)/2;
        String midVal = list.get(midIndex);
		System.out.println("-----> "+startIndex+"; "+endIndex+"; "+midIndex+"; "+midVal+"; "+targetVal);
        if(midVal.contains(targetVal)) {
            return midIndex;
        }

        if(startIndex==endIndex || startIndex>endIndex) {
            return -1;
        }

        if(targetVal.compareTo(midVal)<0) {
            endIndex = midIndex-1;
            return binarySearch(list, startIndex, endIndex, targetVal);
        } else {
            startIndex = midIndex+1;
            return binarySearch(list, startIndex, endIndex, targetVal);
        }
    }
}
