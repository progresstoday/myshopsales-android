package com.example.navigatorapp.other;

import android.app.DatePickerDialog;
import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MyDatePicker {
    final static Calendar myCal1 = Calendar.getInstance();
    static ImageButton dateObj;
    static EditText dateTextObj;
    static Context ct;

    public static void datePicker(Context ct1, EditText dateTextObj1) {
        ct=ct1;
        dateTextObj = dateTextObj1;
        final Calendar myCal = Calendar.getInstance();
        final DatePickerDialog.OnDateSetListener datePicker = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCal.set(Calendar.YEAR,year);
                myCal.set(Calendar.MONTH,month);
                myCal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(dateTextObj,myCal);
            }
        };

        dateTextObj1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_UP) {
                    new DatePickerDialog(ct,datePicker,myCal.get(Calendar.YEAR),myCal.get(Calendar.MONTH),myCal.get(Calendar.DAY_OF_MONTH)).show();
                    return true;
                }
                return false;
            }
        });

    }

    public static void updateLabel(EditText obj,Calendar myCal) {
        obj.setText(new SimpleDateFormat("dd-MM-yyyy").format(myCal.getTime()));
    }
}
