package com.example.navigatorapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.example.navigatorapp.db.DBConstants;
import com.example.navigatorapp.db.DBOperations;
import com.example.navigatorapp.other.MyDatePicker;
import com.example.navigatorapp.other.Validations;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class Activity04_Search_Sales extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    final Calendar myCal = Calendar.getInstance();
    Context ct = this;
    private AwesomeValidation awesomeValidation;

    //Elements
    EditText dateTextObj;
    Button submit;
    CheckBox expenseTodayCb,cashBalanceCb,savingTodayCb,prevRollingCb;
    CheckBox addRollFromBoxCb,addRollFromTSCb,urbanCb,rollTomorrowCb;
    CheckBox boxSavingsCb,totalSavingsCb,businessTodayCb;

    //Values
    String dateVal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity04__search__sales);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.getMenu().getItem(2).setChecked(true);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        initElements();
        setDefaultDate();
        initDatePicker();
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    getValues();
                    if (isDataValid()) {
                        HashMap<String, String> salesToday = DBOperations.getSalesMap(DBConstants.dbHandler.getASaleFromDB(dateVal));
                        if(salesToday==null || salesToday.isEmpty()) {
                            Toast.makeText(Activity04_Search_Sales.this, "No records found with date "+dateVal, Toast.LENGTH_LONG).show();
                        } else {
                            Intent intent = new Intent(Activity04_Search_Sales.this, Activity05_Search_Results.class);
                            intent.putExtra("searchResultSale",getReqSalesRecord(salesToday,getReqFields()));
                            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                            startActivity(intent);
                            overridePendingTransition(0,0);
                        }
                    }
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }
        });

        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Activity04_Search_Sales.this, Activity01_Home.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void navToActivity(Context context, Class<?> cls) {
        Intent intent = new Intent(context, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            navToActivity(Activity04_Search_Sales.this, Activity01_Home.class);
        } else if (id == R.id.nav_create) {
            navToActivity(Activity04_Search_Sales.this, Activity02_Create.class);
        } else if (id == R.id.nav_custom_search) {
            navToActivity(Activity04_Search_Sales.this, Activity06_Create_Report.class);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void initElements() {
        dateTextObj = (EditText) findViewById(R.id.searchDate_editText);
        submit = (Button)findViewById(R.id.searchSalesBtn);
    }

    private void initDatePicker() {
        MyDatePicker.datePicker(ct,dateTextObj);
    }

    private void getValues() {
        dateVal = dateTextObj.getText().toString();
        if(!(dateVal==null || dateVal.equals("") || dateVal.isEmpty())) {
            dateVal=dateVal.substring(6,10)+dateVal.substring(3,5)+dateVal.substring(0,2);
        }
    }

    private boolean isDataValid() throws Exception {
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        validation();
        return awesomeValidation.validate();
    }

    private void validation() throws Exception {
        Validations.dateValidation(awesomeValidation, dateTextObj, dateVal);
    }

    private void initElementsCb() {
        expenseTodayCb = (CheckBox) findViewById(R.id.expenseToday_cb1);
        cashBalanceCb = (CheckBox) findViewById(R.id.cashbal_cb1);
        savingTodayCb = (CheckBox) findViewById(R.id.savingsToday_cb1);
        prevRollingCb = (CheckBox) findViewById(R.id.prevRolling_cb1);
        addRollFromBoxCb = (CheckBox) findViewById(R.id.addRollFromBox_cb1);
        addRollFromTSCb = (CheckBox) findViewById(R.id.addRollFromTS_cb1);
        urbanCb = (CheckBox) findViewById(R.id.urban_cb1);
        rollTomorrowCb = (CheckBox) findViewById(R.id.rollTomorrow_cb1);
        boxSavingsCb = (CheckBox) findViewById(R.id.boxSavings_cb1);
        totalSavingsCb = (CheckBox) findViewById(R.id.totalSavings_cb1);
        businessTodayCb = (CheckBox) findViewById(R.id.businessToday_cb1);
    }

    private ArrayList<String> getReqFields() {
        initElementsCb();

        ArrayList<String> reqFields = new ArrayList<>();
        if(expenseTodayCb.isChecked()) {
            reqFields.add("EXPENSE");
        }
        if(cashBalanceCb.isChecked()) {
            reqFields.add("CASH_BAL");
        }
        if(savingTodayCb.isChecked()) {
            reqFields.add("SAVINGS_TODAY");
        }
        if(businessTodayCb.isChecked()) {
            reqFields.add("BUSINESS_TODAY");
        }
        if(prevRollingCb.isChecked()) {
            reqFields.add("PREV_ROLLING");
        }
        if(addRollFromBoxCb.isChecked()) {
            reqFields.add("ADDITIONAL_ROLL_BOX");
        }
        if(addRollFromTSCb.isChecked()) {
            reqFields.add("ADDITIONAL_ROLL_TS");
        }
        if(urbanCb.isChecked()) {
            reqFields.add("URBAN_COLLECTION");
        }
        if(rollTomorrowCb.isChecked()) {
            reqFields.add("ROLL_TOMORROW");
        }
        if(boxSavingsCb.isChecked()) {
            reqFields.add("BOX_SAVINGS_TODAY");
        }
        if(totalSavingsCb.isChecked()) {
            reqFields.add("TOTAL_SAVINGS_TODAY");
        }
        return reqFields;
    }

    HashMap<String, String> getReqSalesRecord(HashMap<String, String> actMap, ArrayList<String> reqMap) {
        HashMap<String, String> reqSalesMap = new HashMap<>();
        if(reqMap.isEmpty()) {
            reqSalesMap.putAll(actMap);
        } else {
            reqSalesMap.put("DATE",actMap.get("DATE"));
            for(String key: actMap.keySet()) {
                if(reqMap.contains(key)) {
                    reqSalesMap.put(key,actMap.get(key));
                }
            }
        }
        return reqSalesMap;
    }

    private void setDefaultDate() {
        dateTextObj.setText(new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
    }
}
