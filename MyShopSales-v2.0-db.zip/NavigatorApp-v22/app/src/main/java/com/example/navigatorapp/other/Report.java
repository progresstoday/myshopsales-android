package com.example.navigatorapp.other;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import com.example.navigatorapp.R;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class Report {
    static Context ct;

    public static void noDataRow(Context ct1,TableLayout table) {
        ct = ct1;
        TableRow hrow = new TableRow(ct);
        hrow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT));
        TextView hcol4 = new TextView(ct);
        hcol4.setText("No rows present.");
        hrow.addView(hcol4);
        table.addView(hrow);
    }

    public static void createHeaderRow2(Context ct1, TableLayout table, HashMap<String, String> headerMap, Resources res) {
        ct = ct1;
        int noOfFields = headerMap.size();
        TableRow hrow = new TableRow(ct);
        hrow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.WRAP_CONTENT));
        hrow.setWeightSum(noOfFields);
        hrow.setBackgroundResource(R.drawable.row_border);
        addHeaderTextView2(ct,hrow,headerMap,res);
        table.addView(hrow);
    }

    public static void createValueRows2(Context ct1, TableLayout table, List<HashMap<String, String>> listOfMaps) {
        if(listOfMaps.size()==0) {
            return;
        }
        ct = ct1;
        int noOfFields = listOfMaps.get(0).size();
        for(int i=0; i<listOfMaps.size(); i++) {
            HashMap<String, String> map = new HashMap<>(listOfMaps.get(i));
            TableRow row = new TableRow(ct);
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.WRAP_CONTENT));
            row.setWeightSum(noOfFields);
            if(i%2==0) {
                row.setBackgroundResource(R.drawable.row_border1);
            } else {
                row.setBackgroundResource(R.drawable.row_border2);
            }
            addValueTextView2(ct,row,map);
            table.addView(row);
            map.clear();
        }
    }

    static void addHeaderTextView2(Context ct1, TableRow row, HashMap<String, String> headerMap, Resources res) {
        ct = ct1;
        Set<String> keys = headerMap.keySet();

        TextView hcol4 = new TextView(ct);
        hcol4.setText(getReqFieldStrId(res, headerMap.get("DATE")));
        hcol4.setTextColor(Color.parseColor("#FFFFFF"));
        hcol4.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1f));
        hcol4.setPadding(50, 50, 50, 50);
        row.addView(hcol4);

        for(String key: headerMap.keySet()) {
            if(!key.equalsIgnoreCase("DATE")) {
                TextView hcol3 = new TextView(ct);
                hcol3.setText(getReqFieldStrId(res, headerMap.get(key)));
                hcol3.setTextColor(Color.parseColor("#FFFFFF"));
                hcol3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1f));
                hcol3.setPadding(50, 50, 50, 50);
                row.addView(hcol3);
            }
        }

    }

    public static String getReqFieldStrId(Resources res, String str) {
        String str2 = "";
        if("DATE".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.date);
        } else if("EXPENSE".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.expense_today);
        } else if("CASH_BAL".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.cash_balance);
        } else if("SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.savings_today);
        } else if("BUSINESS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.business_today);
        } else if("PREV_ROLLING".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.previous_rolling);
        } else if("ADDITIONAL_ROLL_BOX".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.additional_rolling_from_box);
        } else if("ADDITIONAL_ROLL_TS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.additional_rolling_from_ts);
        } else if("URBAN_COLLECTION".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.urban_collection);
        } else if("ROLL_TOMORROW".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.rolling_tomorrow);
        } else if("BOX_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.box_savings);
        } else if("TOTAL_SAVINGS_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.total_savings);
        } else if("BONUS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.bonus);
        } else if("CASH_BAL_AFTER_BONUS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.cash_balance_after_bonus);
        } else if("PREV_BOX_DEFICIT".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.previous_box_deficit);
        } else if("SAVINGS_TO_REDUCE_BOX_DEFICIT".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.savings_to_reduce_box_deficit);
        } else if("BOX_DEFICIT_TODAY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.box_deficit_today);
        } else if("ELECTRICITY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.electricity);
        } else if("SALARY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.salary);
        } else if("PREV_BOX_SAVINGS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.previous_box_savings);
        } else if("BOX_AMT_TO_TS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.box_amt_to_ts);
        } else if("PREV_TOTAL_SAVINGS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.previous_total_savings);
        } else if("TRANSFERRED_TS_TO_BANK".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.trans_ts_to_bank);
        } else if("EMP1_SALARY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.emp1_salary);
        } else if("EMP2_SALARY".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.emp2_salary);
        } else if("EMP1_BONUS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.emp1_bonus);
        } else if("EMP2_BONUS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.emp2_bonus);
        } else if("EMP3_BONUS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.emp3_bonus);
        } else if("ADD_WITHDRAWL_TS".equalsIgnoreCase(str)) {
            str2 = res.getString(R.string.add_withdrawl_ts);
        } else {
            str2 = str;
        }
        return str2;
    }

    static void addValueTextView2(Context ct1, TableRow row, HashMap<String, String> valueMap) {
        ct = ct1;
        String val1 = valueMap.get("DATE");
        val1 = val1.substring(6,8)+"-"+val1.substring(4,6)+"-"+val1.substring(0,4);
        TextView hcol4 = new TextView(ct);
        hcol4.setText(val1);
        hcol4.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.WRAP_CONTENT,1f));
        hcol4.setPadding(50,50,50,50);
        row.addView(hcol4);

        for(String key:valueMap.keySet()) {
            if(!key.equalsIgnoreCase("DATE")) {
                String val = valueMap.get(key);
                TextView hcol3 = new TextView(ct);
                hcol3.setText(val);
                hcol3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.WRAP_CONTENT,1f));
                hcol3.setPadding(50,50,50,50);
                row.addView(hcol3);
            }
        }
    }
}
