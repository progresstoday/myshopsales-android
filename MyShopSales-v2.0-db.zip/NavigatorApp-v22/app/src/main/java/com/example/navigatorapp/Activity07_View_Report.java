package com.example.navigatorapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.widget.TableLayout;

import com.example.navigatorapp.db.DBConstants;
import com.example.navigatorapp.other.Report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Activity07_View_Report extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    int noOfRecords=5;
    ArrayList<String> reqFieldsList;
    String fileName = "store";
    String filePath;
    Context ct = this;
    TableLayout report_table;
    HashMap<Integer, String> headerMap = new HashMap<>();
    List<HashMap<Integer, String>> valuesListOfMaps = new ArrayList<>();
    HashMap<Integer, String> effHeaderMap = new HashMap<>();
    List<HashMap<Integer, String>> effValuesListOfMaps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity07__view_report);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        noOfRecords = (int)getIntent().getSerializableExtra("no_of_records");
        reqFieldsList = (ArrayList<String>) getIntent().getSerializableExtra("req_fields_list");
        initElements();
        try {
            if(reqFieldsList.isEmpty()) {
                reqFieldsList = DBConstants.dbHandler.getListOfColumnNames();
            }
            List<HashMap<String, String>> sales = DBConstants.dbHandler.getAllSalesFromDB2(reqFieldsList,noOfRecords);
            createTableReport2(sales);
        } catch (Exception e) {
            e.printStackTrace();
        }

        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        navToActivity(Activity07_View_Report.this, Activity06_Create_Report.class);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
            navToActivity(Activity07_View_Report.this, Activity01_Home.class);
        } else if (id == R.id.nav_create) {
            navToActivity(Activity07_View_Report.this, Activity02_Create.class);
        } else if (id == R.id.nav_search_sales) {
            navToActivity(Activity07_View_Report.this, Activity04_Search_Sales.class);
        } else if (id == R.id.nav_custom_search) {
            navToActivity(Activity07_View_Report.this, Activity06_Create_Report.class);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void navToActivity(Context context, Class<?> cls) {
        Intent intent = new Intent(context, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    private void initElements() {
        report_table = (TableLayout) findViewById(R.id.report_table);
    }

    private void createTableReport2(List<HashMap<String, String>> listOfMaps) {
        if(listOfMaps.size()>1) {
            Report.createHeaderRow2(ct, report_table, listOfMaps.get(0), getResources());
            listOfMaps.remove(0);
            Report.createValueRows2(ct, report_table, listOfMaps);
        } else {
            Report.noDataRow(ct, report_table);
        }
    }
}