package com.example.navigatorapp.db;

import android.content.ContentValues;
import android.database.Cursor;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class DBOperations {

    private static int toInt(String str) {
        return Integer.parseInt(str);
    }

    public static ContentValues getContentValues2(HashMap<String,String> sale) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("DATE",sale.get("DATE"));
        contentValues.put("PREV_ROLLING",toInt(sale.get("PREV_ROLLING")));
        contentValues.put("EXPENSE",toInt(sale.get("EXPENSE")));
        contentValues.put("CASH_BAL",toInt(sale.get("CASH_BAL")));
        contentValues.put("BONUS",toInt(sale.get("BONUS")));
        contentValues.put("CASH_BAL_AFTER_BONUS",toInt(sale.get("CASH_BAL_AFTER_BONUS")));
        contentValues.put("BUSINESS_TODAY",toInt(sale.get("BUSINESS_TODAY")));
        contentValues.put("ADDITIONAL_ROLL_BOX",toInt(sale.get("ADDITIONAL_ROLL_BOX")));
        contentValues.put("ADDITIONAL_ROLL_TS",toInt(sale.get("ADDITIONAL_ROLL_TS")));
        contentValues.put("ROLL_TOMORROW",toInt(sale.get("ROLL_TOMORROW")));
        contentValues.put("PREV_BOX_DEFICIT",toInt(sale.get("PREV_BOX_DEFICIT")));
        contentValues.put("SAVINGS_TO_REDUCE_BOX_DEFICIT",toInt(sale.get("SAVINGS_TO_REDUCE_BOX_DEFICIT")));
        contentValues.put("BOX_DEFICIT_TODAY",toInt(sale.get("BOX_DEFICIT_TODAY")));
        contentValues.put("ELECTRICITY",toInt(sale.get("ELECTRICITY")));
        contentValues.put("SALARY",toInt(sale.get("SALARY")));
        contentValues.put("PREV_BOX_SAVINGS",toInt(sale.get("PREV_BOX_SAVINGS")));
        contentValues.put("BOX_SAVINGS_TODAY",toInt(sale.get("BOX_SAVINGS_TODAY")));
        contentValues.put("BOX_AMT_TO_TS",toInt(sale.get("BOX_AMT_TO_TS")));
        contentValues.put("URBAN_COLLECTION",toInt(sale.get("URBAN_COLLECTION")));
        contentValues.put("PREV_TOTAL_SAVINGS",toInt(sale.get("PREV_TOTAL_SAVINGS")));
        contentValues.put("SAVINGS_TODAY",toInt(sale.get("SAVINGS_TODAY")));
        contentValues.put("TOTAL_SAVINGS_TODAY",toInt(sale.get("TOTAL_SAVINGS_TODAY")));
        contentValues.put("TRANSFERRED_TS_TO_BANK",toInt(sale.get("TRANSFERRED_TS_TO_BANK")));
        contentValues.put("EMP1_SALARY",toInt(sale.get("EMP1_SALARY")));
        contentValues.put("EMP2_SALARY",toInt(sale.get("EMP2_SALARY")));
        contentValues.put("EMP1_BONUS",toInt(sale.get("EMP1_BONUS")));
        contentValues.put("EMP2_BONUS",toInt(sale.get("EMP2_BONUS")));
        contentValues.put("EMP3_BONUS",toInt(sale.get("EMP3_BONUS")));
        contentValues.put("ADD_WITHDRAWL_TS",toInt(sale.get("ADD_WITHDRAWL_TS")));
        return contentValues;
    }

    public static ContentValues getContentValues(SalesBean sale) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("DATE",sale.getDATE());
        contentValues.put("PREV_ROLLING",sale.getPREV_ROLLING());
        contentValues.put("EXPENSE",sale.getEXPENSE());
        contentValues.put("CASH_BAL",sale.getCASH_BAL());
        contentValues.put("BONUS",sale.getBONUS());
        contentValues.put("CASH_BAL_AFTER_BONUS",sale.getCASH_BAL_AFTER_BONUS());
        contentValues.put("BUSINESS_TODAY",sale.getBUSINESS_TODAY());
        contentValues.put("ADDITIONAL_ROLL_BOX",sale.getADDITIONAL_ROLL_BOX());
        contentValues.put("ADDITIONAL_ROLL_TS",sale.getADDITIONAL_ROLL_TS());
        contentValues.put("ROLL_TOMORROW",sale.getROLL_TOMORROW());
        contentValues.put("PREV_BOX_DEFICIT",sale.getPREV_BOX_DEFICIT());
        contentValues.put("SAVINGS_TO_REDUCE_BOX_DEFICIT",sale.getSAVINGS_TO_REDUCE_BOX_DEFICIT());
        contentValues.put("BOX_DEFICIT_TODAY",sale.getBOX_DEFICIT_TODAY());
        contentValues.put("ELECTRICITY",sale.getELECTRICITY());
        contentValues.put("SALARY",sale.getSALARY());
        contentValues.put("PREV_BOX_SAVINGS",sale.getPREV_BOX_SAVINGS());
        contentValues.put("BOX_SAVINGS_TODAY",sale.getBOX_SAVINGS_TODAY());
        contentValues.put("BOX_AMT_TO_TS",sale.getBOX_AMT_TO_TS());
        contentValues.put("URBAN_COLLECTION",sale.getURBAN_COLLECTION());
        contentValues.put("PREV_TOTAL_SAVINGS",sale.getPREV_TOTAL_SAVINGS());
        contentValues.put("SAVINGS_TODAY",sale.getSAVINGS_TODAY());
        contentValues.put("TOTAL_SAVINGS_TODAY",sale.getTOTAL_SAVINGS_TODAY());
        contentValues.put("TRANSFERRED_TS_TO_BANK",sale.getTRANSFERRED_TS_TO_BANK());
        contentValues.put("EMP1_SALARY",sale.getEMP1_SALARY());
        contentValues.put("EMP2_SALARY",sale.getEMP2_SALARY());
        contentValues.put("EMP1_BONUS",sale.getEMP1_BONUS());
        contentValues.put("EMP2_BONUS",sale.getEMP2_BONUS());
        contentValues.put("EMP3_BONUS",sale.getEMP3_BONUS());
        contentValues.put("ADD_WITHDRAWL_TS",sale.getADD_WITHDRAWL_TS());
        return contentValues;
    }

    public static SalesBean getSale(Cursor cursor) {
        SalesBean sale = null;
        if(cursor!=null && cursor.moveToFirst()) {
            sale = getTempSale(cursor);
            cursor.close();
        }
        return sale;
    }

    public static ArrayList<String> getColumnsList(Cursor cursor) {
        return new ArrayList(Arrays.asList(cursor.getColumnNames()));
    }

    public static List<HashMap<String, String>> getListOfSales2(Cursor cursor, int noOfSales, boolean addHeaders) {
        List<HashMap<String, String>> listOfSales = new ArrayList<>();
        if(addHeaders) {
            HashMap<String,String> tempMap = new HashMap<>();
            for(String str: cursor.getColumnNames()) {
                tempMap.put(str,str);
            }
            listOfSales.add(0,tempMap);
        }

        if(cursor!=null && cursor.moveToFirst()) {
            do {
                HashMap<String,String> tempMap2 = new HashMap<>();
                for(String str: cursor.getColumnNames()) {
                    tempMap2.put(str,cursor.getString(cursor.getColumnIndex(str)));
                }
                listOfSales.add(tempMap2);
            } while(--noOfSales>0 && cursor.moveToNext());
        }
        return listOfSales;
    }

    public static List<SalesBean> getListOfSales(Cursor cursor, int noOfSales) {
        List<SalesBean> listOfSales = new ArrayList<>();
        if(cursor!=null && cursor.moveToFirst()) {
            do {
                listOfSales.add(getTempSale(cursor));
            } while(--noOfSales>0 && cursor.moveToNext());
        }
        return listOfSales;
    }

    private static SalesBean getTempSale2(ArrayList<String> reqCols, Cursor cursor) {
        SalesBean tempSale = new SalesBean();
        tempSale.setDATE(cursor.getString(cursor.getColumnIndex("DATE")));
        tempSale.setPREV_ROLLING(cursor.getInt(cursor.getColumnIndex("PREV_ROLLING")));
        tempSale.setEXPENSE(cursor.getInt(cursor.getColumnIndex("EXPENSE")));
        tempSale.setCASH_BAL(cursor.getInt(cursor.getColumnIndex("CASH_BAL")));
        tempSale.setBONUS(cursor.getInt(cursor.getColumnIndex("BONUS")));
        tempSale.setCASH_BAL_AFTER_BONUS(cursor.getInt(cursor.getColumnIndex("CASH_BAL_AFTER_BONUS")));
        tempSale.setBUSINESS_TODAY(cursor.getInt(cursor.getColumnIndex("BUSINESS_TODAY")));
        tempSale.setADDITIONAL_ROLL_BOX(cursor.getInt(cursor.getColumnIndex("ADDITIONAL_ROLL_BOX")));
        tempSale.setADDITIONAL_ROLL_TS(cursor.getInt(cursor.getColumnIndex("ADDITIONAL_ROLL_TS")));
        tempSale.setROLL_TOMORROW(cursor.getInt(cursor.getColumnIndex("ROLL_TOMORROW")));
        tempSale.setPREV_BOX_DEFICIT(cursor.getInt(cursor.getColumnIndex("PREV_BOX_DEFICIT")));
        tempSale.setSAVINGS_TO_REDUCE_BOX_DEFICIT(cursor.getInt(cursor.getColumnIndex("SAVINGS_TO_REDUCE_BOX_DEFICIT")));
        tempSale.setBOX_DEFICIT_TODAY(cursor.getInt(cursor.getColumnIndex("BOX_DEFICIT_TODAY")));
        tempSale.setELECTRICITY(cursor.getInt(cursor.getColumnIndex("ELECTRICITY")));
        tempSale.setSALARY(cursor.getInt(cursor.getColumnIndex("SALARY")));
        tempSale.setPREV_BOX_SAVINGS(cursor.getInt(cursor.getColumnIndex("PREV_BOX_SAVINGS")));
        tempSale.setBOX_SAVINGS_TODAY(cursor.getInt(cursor.getColumnIndex("BOX_SAVINGS_TODAY")));
        tempSale.setBOX_AMT_TO_TS(cursor.getInt(cursor.getColumnIndex("BOX_AMT_TO_TS")));
        tempSale.setURBAN_COLLECTION(cursor.getInt(cursor.getColumnIndex("URBAN_COLLECTION")));
        tempSale.setPREV_TOTAL_SAVINGS(cursor.getInt(cursor.getColumnIndex("PREV_TOTAL_SAVINGS")));
        tempSale.setSAVINGS_TODAY(cursor.getInt(cursor.getColumnIndex("SAVINGS_TODAY")));
        tempSale.setTOTAL_SAVINGS_TODAY(cursor.getInt(cursor.getColumnIndex("TOTAL_SAVINGS_TODAY")));
        tempSale.setTRANSFERRED_TS_TO_BANK(cursor.getInt(cursor.getColumnIndex("TRANSFERRED_TS_TO_BANK")));
        tempSale.setEMP1_SALARY(cursor.getInt(cursor.getColumnIndex("EMP1_SALARY")));
        tempSale.setEMP2_SALARY(cursor.getInt(cursor.getColumnIndex("EMP2_SALARY")));
        tempSale.setEMP1_BONUS(cursor.getInt(cursor.getColumnIndex("EMP1_BONUS")));
        tempSale.setEMP2_BONUS(cursor.getInt(cursor.getColumnIndex("EMP2_BONUS")));
        tempSale.setEMP3_BONUS(cursor.getInt(cursor.getColumnIndex("EMP3_BONUS")));
        tempSale.setADD_WITHDRAWL_TS(cursor.getInt(cursor.getColumnIndex("ADD_WITHDRAWL_TS")));
        return tempSale;
    }

    private static SalesBean getTempSale(Cursor cursor) {
        SalesBean tempSale = new SalesBean();
        tempSale.setDATE(cursor.getString(cursor.getColumnIndex("DATE")));
        tempSale.setPREV_ROLLING(cursor.getInt(cursor.getColumnIndex("PREV_ROLLING")));
        tempSale.setEXPENSE(cursor.getInt(cursor.getColumnIndex("EXPENSE")));
        tempSale.setCASH_BAL(cursor.getInt(cursor.getColumnIndex("CASH_BAL")));
        tempSale.setBONUS(cursor.getInt(cursor.getColumnIndex("BONUS")));
        tempSale.setCASH_BAL_AFTER_BONUS(cursor.getInt(cursor.getColumnIndex("CASH_BAL_AFTER_BONUS")));
        tempSale.setBUSINESS_TODAY(cursor.getInt(cursor.getColumnIndex("BUSINESS_TODAY")));
        tempSale.setADDITIONAL_ROLL_BOX(cursor.getInt(cursor.getColumnIndex("ADDITIONAL_ROLL_BOX")));
        tempSale.setADDITIONAL_ROLL_TS(cursor.getInt(cursor.getColumnIndex("ADDITIONAL_ROLL_TS")));
        tempSale.setROLL_TOMORROW(cursor.getInt(cursor.getColumnIndex("ROLL_TOMORROW")));
        tempSale.setPREV_BOX_DEFICIT(cursor.getInt(cursor.getColumnIndex("PREV_BOX_DEFICIT")));
        tempSale.setSAVINGS_TO_REDUCE_BOX_DEFICIT(cursor.getInt(cursor.getColumnIndex("SAVINGS_TO_REDUCE_BOX_DEFICIT")));
        tempSale.setBOX_DEFICIT_TODAY(cursor.getInt(cursor.getColumnIndex("BOX_DEFICIT_TODAY")));
        tempSale.setELECTRICITY(cursor.getInt(cursor.getColumnIndex("ELECTRICITY")));
        tempSale.setSALARY(cursor.getInt(cursor.getColumnIndex("SALARY")));
        tempSale.setPREV_BOX_SAVINGS(cursor.getInt(cursor.getColumnIndex("PREV_BOX_SAVINGS")));
        tempSale.setBOX_SAVINGS_TODAY(cursor.getInt(cursor.getColumnIndex("BOX_SAVINGS_TODAY")));
        tempSale.setBOX_AMT_TO_TS(cursor.getInt(cursor.getColumnIndex("BOX_AMT_TO_TS")));
        tempSale.setURBAN_COLLECTION(cursor.getInt(cursor.getColumnIndex("URBAN_COLLECTION")));
        tempSale.setPREV_TOTAL_SAVINGS(cursor.getInt(cursor.getColumnIndex("PREV_TOTAL_SAVINGS")));
        tempSale.setSAVINGS_TODAY(cursor.getInt(cursor.getColumnIndex("SAVINGS_TODAY")));
        tempSale.setTOTAL_SAVINGS_TODAY(cursor.getInt(cursor.getColumnIndex("TOTAL_SAVINGS_TODAY")));
        tempSale.setTRANSFERRED_TS_TO_BANK(cursor.getInt(cursor.getColumnIndex("TRANSFERRED_TS_TO_BANK")));
        tempSale.setEMP1_SALARY(cursor.getInt(cursor.getColumnIndex("EMP1_SALARY")));
        tempSale.setEMP2_SALARY(cursor.getInt(cursor.getColumnIndex("EMP2_SALARY")));
        tempSale.setEMP1_BONUS(cursor.getInt(cursor.getColumnIndex("EMP1_BONUS")));
        tempSale.setEMP2_BONUS(cursor.getInt(cursor.getColumnIndex("EMP2_BONUS")));
        tempSale.setEMP3_BONUS(cursor.getInt(cursor.getColumnIndex("EMP3_BONUS")));
        tempSale.setADD_WITHDRAWL_TS(cursor.getInt(cursor.getColumnIndex("ADD_WITHDRAWL_TS")));
        return tempSale;
    }

    public static String getPreviousDate(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date dateObj = null;
        try {
             dateObj = sdf.parse(date);
        } catch (Exception e) {e.printStackTrace();}
        Calendar cal = Calendar.getInstance();
        cal.setTime(dateObj);
        cal.add(Calendar.DATE, -1);
        return sdf.format(cal.getTime());
    }

    public static HashMap<String, String> getSalesMap(SalesBean sale) {
        HashMap<String, String> contentValues = new HashMap<>();
        if(sale!=null) {
            contentValues.put("DATE", sale.getDATE());
            contentValues.put("PREV_ROLLING", sale.getPREV_ROLLING() + "");
            contentValues.put("EXPENSE", sale.getEXPENSE() + "");
            contentValues.put("CASH_BAL", sale.getCASH_BAL() + "");
            contentValues.put("BONUS", sale.getBONUS() + "");
            contentValues.put("CASH_BAL_AFTER_BONUS", sale.getCASH_BAL_AFTER_BONUS() + "");
            contentValues.put("BUSINESS_TODAY", sale.getBUSINESS_TODAY() + "");
            contentValues.put("ADDITIONAL_ROLL_BOX", sale.getADDITIONAL_ROLL_BOX() + "");
            contentValues.put("ADDITIONAL_ROLL_TS", sale.getADDITIONAL_ROLL_TS() + "");
            contentValues.put("ROLL_TOMORROW", sale.getROLL_TOMORROW() + "");
            contentValues.put("PREV_BOX_DEFICIT", sale.getPREV_BOX_DEFICIT() + "");
            contentValues.put("SAVINGS_TO_REDUCE_BOX_DEFICIT", sale.getSAVINGS_TO_REDUCE_BOX_DEFICIT() + "");
            contentValues.put("BOX_DEFICIT_TODAY", sale.getBOX_DEFICIT_TODAY() + "");
            contentValues.put("ELECTRICITY", sale.getELECTRICITY() + "");
            contentValues.put("SALARY", sale.getSALARY() + "");
            contentValues.put("PREV_BOX_SAVINGS", sale.getPREV_BOX_SAVINGS() + "");
            contentValues.put("BOX_SAVINGS_TODAY", sale.getBOX_SAVINGS_TODAY() + "");
            contentValues.put("BOX_AMT_TO_TS", sale.getBOX_AMT_TO_TS() + "");
            contentValues.put("URBAN_COLLECTION", sale.getURBAN_COLLECTION() + "");
            contentValues.put("PREV_TOTAL_SAVINGS", sale.getPREV_TOTAL_SAVINGS() + "");
            contentValues.put("SAVINGS_TODAY", sale.getSAVINGS_TODAY() + "");
            contentValues.put("TOTAL_SAVINGS_TODAY", sale.getTOTAL_SAVINGS_TODAY() + "");
            contentValues.put("TRANSFERRED_TS_TO_BANK", sale.getTRANSFERRED_TS_TO_BANK() + "");
            contentValues.put("EMP1_SALARY", sale.getEMP1_SALARY() + "");
            contentValues.put("EMP2_SALARY", sale.getEMP2_SALARY() + "");
            contentValues.put("EMP1_BONUS", sale.getEMP1_BONUS() + "");
            contentValues.put("EMP2_BONUS", sale.getEMP2_BONUS() + "");
            contentValues.put("EMP3_BONUS", sale.getEMP3_BONUS() + "");
            contentValues.put("ADD_WITHDRAWL_TS", sale.getADD_WITHDRAWL_TS() + "");
        }
        return contentValues;
    }
}