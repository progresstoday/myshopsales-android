package com.example.navigatorapp.db;

import java.util.ArrayList;

public class DBConstants {
    public static DBHandler dbHandler = null;

    final static String DB_NAME = "store3";
    final static String TABLE_NAME = "sales3";
    final static String PK = "DATE";
    final static String[] COLUMN_NAMES = new String[]{"DATE","PREV_ROLLING","EXPENSE","CASH_BAL","BONUS","CASH_BAL_AFTER_BONUS","BUSINESS_TODAY","ADDITIONAL_ROLL_BOX","ADDITIONAL_ROLL_TS","ROLL_TOMORROW","PREV_BOX_DEFICIT","SAVINGS_TO_REDUCE_BOX_DEFICIT","BOX_DEFICIT_TODAY","ELECTRICITY","SALARY","PREV_BOX_SAVINGS","BOX_SAVINGS_TODAY","BOX_AMT_TO_TS","URBAN_COLLECTION","PREV_TOTAL_SAVINGS","SAVINGS_TODAY","TOTAL_SAVINGS_TODAY","TRANSFERRED_TS_TO_BANK","EMP1_SALARY","EMP2_SALARY","EMP1_BONUS","EMP2_BONUS","EMP3_BONUS","ADD_WITHDRAWL_TS"};

    final static String QUERY_CREATE_TABLE = "CREATE TABLE "+TABLE_NAME+" (" +
            "DATE TEXT PRIMARY KEY," +
            "PREV_ROLLING TEXT," +
            "EXPENSE TEXT," +
            "CASH_BAL TEXT," +
            "BONUS TEXT," +
            "CASH_BAL_AFTER_BONUS TEXT," +
            "BUSINESS_TODAY TEXT," +
            "ADDITIONAL_ROLL_BOX TEXT," +
            "ADDITIONAL_ROLL_TS TEXT," +
            "ROLL_TOMORROW TEXT," +
            "PREV_BOX_DEFICIT TEXT," +
            "SAVINGS_TO_REDUCE_BOX_DEFICIT TEXT," +
            "BOX_DEFICIT_TODAY TEXT," +
            "ELECTRICITY TEXT," +
            "SALARY TEXT," +
            "PREV_BOX_SAVINGS TEXT," +
            "BOX_SAVINGS_TODAY TEXT," +
            "BOX_AMT_TO_TS TEXT," +
            "URBAN_COLLECTION TEXT," +
            "PREV_TOTAL_SAVINGS TEXT," +
            "SAVINGS_TODAY TEXT," +
            "TOTAL_SAVINGS_TODAY TEXT," +
            "TRANSFERRED_TS_TO_BANK TEXT," +
            "EMP1_SALARY TEXT," +
            "EMP2_SALARY TEXT," +
            "EMP1_BONUS TEXT," +
            "EMP2_BONUS TEXT," +
            "EMP3_BONUS TEXT," +
            "ADD_WITHDRAWL_TS TEXT" +
        ")";
    final static String QUERY_DROP_TABLE = "DROP TABLE IF EXISTS "+TABLE_NAME;
    final static String QUERY_SELECT_ALL_SALES = "SELECT * FROM "+TABLE_NAME+" ORDER BY "+PK+" DESC";

    public static String reqSelectQueryFromColumnList(ArrayList<String> list) {
        String reqStr = list.get(0);
        if(!list.contains("DATE")) {
            reqStr = "DATE,"+list.get(0);
        }

        for(int i=1;i<list.size();i++) {
            reqStr = reqStr+","+list.get(i);
        }
        reqStr = "SELECT "+reqStr+" FROM "+TABLE_NAME+" ORDER BY "+PK+" DESC";
        return reqStr;
    }

}
