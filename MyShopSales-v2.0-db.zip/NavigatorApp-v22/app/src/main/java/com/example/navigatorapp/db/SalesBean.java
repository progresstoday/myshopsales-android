package com.example.navigatorapp.db;

public class SalesBean {

    private String DATE;
    private int PREV_ROLLING;
    private int EXPENSE;
    private int CASH_BAL;
    private int BONUS;
    private int CASH_BAL_AFTER_BONUS;
    private int BUSINESS_TODAY;
    private int ADDITIONAL_ROLL_BOX;
    private int ADDITIONAL_ROLL_TS;
    private int ROLL_TOMORROW;
    private int PREV_BOX_DEFICIT;
    private int SAVINGS_TO_REDUCE_BOX_DEFICIT;
    private int BOX_DEFICIT_TODAY;
    private int ELECTRICITY;
    private int SALARY;
    private int PREV_BOX_SAVINGS;
    private int BOX_SAVINGS_TODAY;
    private int BOX_AMT_TO_TS;
    private int URBAN_COLLECTION;
    private int PREV_TOTAL_SAVINGS;
    private int SAVINGS_TODAY;
    private int TOTAL_SAVINGS_TODAY;
    private int TRANSFERRED_TS_TO_BANK;
    private int EMP1_SALARY;
    private int EMP2_SALARY;
    private int EMP1_BONUS;
    private int EMP2_BONUS;
    private int EMP3_BONUS;
    private int ADD_WITHDRAWL_TS;

    public String getDATE() {
        return DATE;
    }

    public void setDATE(String DATE) {
        this.DATE = DATE;
    }

    public int getPREV_ROLLING() {
        return PREV_ROLLING;
    }

    public void setPREV_ROLLING(int PREV_ROLLING) {
        this.PREV_ROLLING = PREV_ROLLING;
    }

    public int getEXPENSE() {
        return EXPENSE;
    }

    public void setEXPENSE(int EXPENSE) {
        this.EXPENSE = EXPENSE;
    }

    public int getCASH_BAL() {
        return CASH_BAL;
    }

    public void setCASH_BAL(int CASH_BAL) {
        this.CASH_BAL = CASH_BAL;
    }

    public int getBONUS() {
        return BONUS;
    }

    public void setBONUS(int BONUS) {
        this.BONUS = BONUS;
    }

    public int getCASH_BAL_AFTER_BONUS() {
        return CASH_BAL_AFTER_BONUS;
    }

    public void setCASH_BAL_AFTER_BONUS(int CASH_BAL_AFTER_BONUS) {
        this.CASH_BAL_AFTER_BONUS = CASH_BAL_AFTER_BONUS;
    }

    public int getBUSINESS_TODAY() {
        return BUSINESS_TODAY;
    }

    public void setBUSINESS_TODAY(int BUSINESS_TODAY) {
        this.BUSINESS_TODAY = BUSINESS_TODAY;
    }

    public int getADDITIONAL_ROLL_BOX() {
        return ADDITIONAL_ROLL_BOX;
    }

    public void setADDITIONAL_ROLL_BOX(int ADDITIONAL_ROLL_BOX) {
        this.ADDITIONAL_ROLL_BOX = ADDITIONAL_ROLL_BOX;
    }

    public int getADDITIONAL_ROLL_TS() {
        return ADDITIONAL_ROLL_TS;
    }

    public void setADDITIONAL_ROLL_TS(int ADDITIONAL_ROLL_TS) {
        this.ADDITIONAL_ROLL_TS = ADDITIONAL_ROLL_TS;
    }

    public int getROLL_TOMORROW() {
        return ROLL_TOMORROW;
    }

    public void setROLL_TOMORROW(int ROLL_TOMORROW) {
        this.ROLL_TOMORROW = ROLL_TOMORROW;
    }

    public int getPREV_BOX_DEFICIT() {
        return PREV_BOX_DEFICIT;
    }

    public void setPREV_BOX_DEFICIT(int PREV_BOX_DEFICIT) {
        this.PREV_BOX_DEFICIT = PREV_BOX_DEFICIT;
    }

    public int getSAVINGS_TO_REDUCE_BOX_DEFICIT() {
        return SAVINGS_TO_REDUCE_BOX_DEFICIT;
    }

    public void setSAVINGS_TO_REDUCE_BOX_DEFICIT(int SAVINGS_TO_REDUCE_BOX_DEFICIT) {
        this.SAVINGS_TO_REDUCE_BOX_DEFICIT = SAVINGS_TO_REDUCE_BOX_DEFICIT;
    }

    public int getBOX_DEFICIT_TODAY() {
        return BOX_DEFICIT_TODAY;
    }

    public void setBOX_DEFICIT_TODAY(int BOX_DEFICIT_TODAY) {
        this.BOX_DEFICIT_TODAY = BOX_DEFICIT_TODAY;
    }

    public int getELECTRICITY() {
        return ELECTRICITY;
    }

    public void setELECTRICITY(int ELECTRICITY) {
        this.ELECTRICITY = ELECTRICITY;
    }

    public int getSALARY() {
        return SALARY;
    }

    public void setSALARY(int SALARY) {
        this.SALARY = SALARY;
    }

    public int getPREV_BOX_SAVINGS() {
        return PREV_BOX_SAVINGS;
    }

    public void setPREV_BOX_SAVINGS(int PREV_BOX_SAVINGS) {
        this.PREV_BOX_SAVINGS = PREV_BOX_SAVINGS;
    }

    public int getBOX_SAVINGS_TODAY() {
        return BOX_SAVINGS_TODAY;
    }

    public void setBOX_SAVINGS_TODAY(int BOX_SAVINGS_TODAY) {
        this.BOX_SAVINGS_TODAY = BOX_SAVINGS_TODAY;
    }

    public int getBOX_AMT_TO_TS() {
        return BOX_AMT_TO_TS;
    }

    public void setBOX_AMT_TO_TS(int BOX_AMT_TO_TS) {
        this.BOX_AMT_TO_TS = BOX_AMT_TO_TS;
    }

    public int getURBAN_COLLECTION() {
        return URBAN_COLLECTION;
    }

    public void setURBAN_COLLECTION(int URBAN_COLLECTION) {
        this.URBAN_COLLECTION = URBAN_COLLECTION;
    }

    public int getPREV_TOTAL_SAVINGS() {
        return PREV_TOTAL_SAVINGS;
    }

    public void setPREV_TOTAL_SAVINGS(int PREV_TOTAL_SAVINGS) {
        this.PREV_TOTAL_SAVINGS = PREV_TOTAL_SAVINGS;
    }

    public int getSAVINGS_TODAY() {
        return SAVINGS_TODAY;
    }

    public void setSAVINGS_TODAY(int SAVINGS_TODAY) {
        this.SAVINGS_TODAY = SAVINGS_TODAY;
    }

    public int getTOTAL_SAVINGS_TODAY() {
        return TOTAL_SAVINGS_TODAY;
    }

    public void setTOTAL_SAVINGS_TODAY(int TOTAL_SAVINGS_TODAY) {
        this.TOTAL_SAVINGS_TODAY = TOTAL_SAVINGS_TODAY;
    }

    public int getTRANSFERRED_TS_TO_BANK() {
        return TRANSFERRED_TS_TO_BANK;
    }

    public void setTRANSFERRED_TS_TO_BANK(int TRANSFERRED_TS_TO_BANK) {
        this.TRANSFERRED_TS_TO_BANK = TRANSFERRED_TS_TO_BANK;
    }

    public int getEMP1_SALARY() {
        return EMP1_SALARY;
    }

    public void setEMP1_SALARY(int EMP1_SALARY) {
        this.EMP1_SALARY = EMP1_SALARY;
    }

    public int getEMP2_SALARY() {
        return EMP2_SALARY;
    }

    public void setEMP2_SALARY(int EMP2_SALARY) {
        this.EMP2_SALARY = EMP2_SALARY;
    }

    public int getEMP1_BONUS() {
        return EMP1_BONUS;
    }

    public void setEMP1_BONUS(int EMP1_BONUS) {
        this.EMP1_BONUS = EMP1_BONUS;
    }

    public int getEMP2_BONUS() {
        return EMP2_BONUS;
    }

    public void setEMP2_BONUS(int EMP2_BONUS) {
        this.EMP2_BONUS = EMP2_BONUS;
    }

    public int getEMP3_BONUS() {
        return EMP3_BONUS;
    }

    public void setEMP3_BONUS(int EMP3_BONUS) {
        this.EMP3_BONUS = EMP3_BONUS;
    }

    public int getADD_WITHDRAWL_TS() {
        return ADD_WITHDRAWL_TS;
    }

    public void setADD_WITHDRAWL_TS(int ADD_WITHDRAWL_TS) {
        this.ADD_WITHDRAWL_TS = ADD_WITHDRAWL_TS;
    }
}
