package com.example.navigatorapp;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.navigatorapp.other.Report;

import java.util.HashMap;
import java.util.Set;

public class Activity05_Search_Results extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    int padding = 10;
    Context ct = this;
    TableLayout report_table;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity05__search__results);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        @SuppressWarnings("unchecked")
        HashMap<String,String> salesToday = (HashMap<String, String>)getIntent().getSerializableExtra("searchResultSale");
        createTableReport(salesToday);

        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        navToActivity(Activity05_Search_Results.this, Activity04_Search_Sales.class);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void navToActivity(Context context, Class<?> cls) {
        Intent intent = new Intent(context, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        overridePendingTransition(0,0);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            navToActivity(Activity05_Search_Results.this, Activity01_Home.class);
        } else if (id == R.id.nav_create) {
            navToActivity(Activity05_Search_Results.this, Activity02_Create.class);
        } else if (id == R.id.nav_search_sales) {
            navToActivity(Activity05_Search_Results.this, Activity04_Search_Sales.class);
        } else if (id == R.id.nav_custom_search) {
            navToActivity(Activity05_Search_Results.this, Activity06_Create_Report.class);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void initElementsTable() {
        report_table = (TableLayout) findViewById(R.id.report_table1);
    }

    private void createTableReport(HashMap<String, String> map) {
        initElementsTable();
        createHeaderRow1(report_table, map.get("DATE"));
        int i=0;
        for(String key: map.keySet()) {
            int color = R.drawable.row_border3;
            if(i%2==1) {
                color = R.drawable.row_border1;
            }
            if(!"DATE".equalsIgnoreCase(key)) {
                createHeaderRow(report_table, map, key, color);
            }
            i++;
        }
    }

    public void createHeaderRow1(TableLayout table, String date) {
        TableRow hrow = new TableRow(ct);
        hrow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT));
        hrow.setWeightSum(2);
        hrow.setBackgroundResource(R.drawable.row_border);
        addHeaderTextView(hrow, date);
        table.addView(hrow);
    }

    void addHeaderTextView(TableRow row, String tempDate) {
        tempDate = tempDate.substring(6,8)+"-"+tempDate.substring(4,6)+"-"+tempDate.substring(0,4);
        TextView hcol3 = new TextView(ct);
        hcol3.setText("Sales on "+tempDate);
        hcol3.setGravity(Gravity.CENTER);
        hcol3.setTextColor(Color.parseColor("#FFFFFF"));
        hcol3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT,2f));
        hcol3.setPadding(padding,padding,padding,padding);
        row.addView(hcol3);
    }

    public void createHeaderRow(TableLayout table, HashMap<String, String> map, String key, int color) {
        TableRow hrow = new TableRow(ct);
        hrow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT));
        hrow.setWeightSum(2);
        hrow.setBackgroundResource(color);
        addHeaderTextView(hrow,map,key);
        table.addView(hrow);
    }

    void addHeaderTextView(TableRow row, HashMap<String, String> map, String key) {
        TextView hcol3 = new TextView(ct);
        hcol3.setText(Report.getReqFieldStrId(getResources(),key));
        hcol3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT,1f));
        hcol3.setPadding(padding,padding,padding,padding);
        row.addView(hcol3);

        TextView hcol4 = new TextView(ct);
        if("DATE".equalsIgnoreCase(key)) {
            String tempDate = map.get(key);
            tempDate = tempDate.substring(6,8)+"-"+tempDate.substring(4,6)+"-"+tempDate.substring(0,4);
            hcol4.setText(tempDate);
        } else {
            hcol4.setText(map.get(key));
        }
        hcol4.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT,1f));
        hcol4.setPadding(padding,padding,padding,padding);
        row.addView(hcol4);
    }

}

