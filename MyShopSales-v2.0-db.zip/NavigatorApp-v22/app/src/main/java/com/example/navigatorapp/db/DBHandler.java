package com.example.navigatorapp.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {

    public DBHandler(Context context) {
        super(context,DBConstants.DB_NAME,null,1);
    }

    private Cursor getCursorData(String[] colToSelect, String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(DBConstants.TABLE_NAME,colToSelect,DBConstants.PK+"=?",new String[]{date},null,null,null,null);
    }

    private boolean checkSaleExistsInDB(String date) {
        int noOfResults = 0;
        Cursor cursor = getCursorData(new String[]{DBConstants.PK},date);
        if(cursor!=null) {
            noOfResults = cursor.getCount();
        }
        return noOfResults>0?true:false;
    }

    public List<HashMap<String, String>> getAllSalesFromDB2(ArrayList<String> reqCols, int noOfSales) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(DBConstants.reqSelectQueryFromColumnList(reqCols),null);
        return DBOperations.getListOfSales2(cursor,noOfSales,true);
    }

    public ArrayList<String> getListOfColumnNames() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(DBConstants.TABLE_NAME,null,null,null,null,null,null);
        return DBOperations.getColumnsList(cursor);
    }

    public List<SalesBean> getAllSalesFromDB(int noOfSales) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(DBConstants.QUERY_SELECT_ALL_SALES,null);
        return DBOperations.getListOfSales(cursor,noOfSales);
    }

    public SalesBean getASaleFromDB(String date) {
        return DBOperations.getSale(getCursorData(DBConstants.COLUMN_NAMES,date));
    }

    public SalesBean getPrevDaySaleFromDB(String date) {
        return DBOperations.getSale(getCursorData(DBConstants.COLUMN_NAMES,DBOperations.getPreviousDate(date)));
    }

    public void insertSaleInDB2(HashMap<String,String> sale) {
        String date = sale.get("DATE");
        if(checkSaleExistsInDB(date)) {
            updateSaleInDB2(sale);
        } else {
            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DBConstants.TABLE_NAME,null,DBOperations.getContentValues2(sale));
            db.close();
        }
    }

    public void insertSaleInDB(SalesBean sale) {
        String date = sale.getDATE();
        if(checkSaleExistsInDB(date)) {
            updateSaleInDB(sale);
        } else {
            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DBConstants.TABLE_NAME,null,DBOperations.getContentValues(sale));
            db.close();
        }
    }

    private void updateSaleInDB2(HashMap<String,String> sale) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.update(DBConstants.TABLE_NAME,DBOperations.getContentValues2(sale),"DATE=?",new String[] {sale.get("DATE")});
        db.close();
    }

    private void updateSaleInDB(SalesBean sale) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.update(DBConstants.TABLE_NAME,DBOperations.getContentValues(sale),"DATE=?",new String[] {sale.getDATE()});
        db.close();
    }

    public void deleteSalesInDB() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(DBConstants.TABLE_NAME,null,null);
        db.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DBConstants.QUERY_CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DBConstants.QUERY_DROP_TABLE);
        onCreate(db);
    }
}
