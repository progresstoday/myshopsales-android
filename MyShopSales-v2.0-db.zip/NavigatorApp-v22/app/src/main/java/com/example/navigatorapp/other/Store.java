package com.example.navigatorapp.other;

import java.util.HashMap;

public class Store {

	HashMap<String,String> salesToday = new HashMap<String, String>();
	private HashMap<String, String> prevSalesData = new HashMap<String, String>();

	//Inputs
	private String date;
	private int expenseToday;
	private int cashBalanceToday;
	private int savingsToday;
	private int rollingTomorrow;
	private int addRollingFromBox;
	private int addRollingFromTotalSavings;
	private int savingsToRemoveBoxDeficit;
	private int urbanCollection;
	private int electricity;
	private int salary;
	private int bonus;
	private int amountToMoveFromTotalSavingsToBank;
	private boolean moveBoxAmountToTotalSavings;

	//Prev
	private int prevRolling;
	private int prevBoxDeficit;
	private int prevTotalSavings;
	private int prevBoxSavings;

	private int emp1Salary,emp2Salary,emp1Bonus,emp2Bonus,emp3Bonus,addWithdrawlFromTS;

	public Store(String date, HashMap<String, String> prevSalesData) {
		this.date = date;
		this.prevSalesData = prevSalesData;
	}

	public HashMap<String, String> getPrevSalesData() {
		return prevSalesData;
	}

	//direct getters
	public String getDate() {
		return date;
	}

	public int getExpenseToday() {
		return expenseToday;
	}

	public int getCashBalanceToday() {
		return cashBalanceToday;
	}

	public int getSavingsToday() {
		return savingsToday;
	}

	public int getRollingTomorrow() {
		return rollingTomorrow;
	}

	public int getAddRollingFromBox() {
		return addRollingFromBox;
	}

	public int getAddRollingFromTotalSavings() {
		return addRollingFromTotalSavings;
	}

	public int getSavingsToRemoveBoxDeficit() {
		return savingsToRemoveBoxDeficit;
	}

	public int getUrbanCollection() {
		return urbanCollection;
	}

	public int getElectricity() {
		return electricity;
	}

	public int getSalary() {
		return salary;
	}

	public int getBonus() {
		return bonus;
	}

	public int getAmountToMoveFromTotalSavingsToBank() {
		return amountToMoveFromTotalSavingsToBank;
	}

	public boolean isBoxAmtTransfferedToTotalSavings() {
		return moveBoxAmountToTotalSavings;
	}
	//-----------------------------

	//Prev Sales Data
	public int getPrevRolling() {
		prevRolling = Integer.parseInt(prevSalesData.get("ROLL_TOMORROW"));
		return prevRolling;
	}

	public int getPrevBoxDeficit() {
		prevBoxDeficit = Integer.parseInt(prevSalesData.get("BOX_DEFICIT_TODAY"));
		return prevBoxDeficit;
	}

	public int getPrevTotalSavings() {
		prevTotalSavings = Integer.parseInt(prevSalesData.get("TOTAL_SAVINGS_TODAY"));
		return prevTotalSavings;
	}

	public int getPrevBoxSavings() {
		prevBoxSavings = Integer.parseInt(prevSalesData.get("BOX_SAVINGS_TODAY"));
		return prevBoxSavings;
	}
	//------------------------------

	//normal setters
	public void setExpenseToday(int expenseToday) {
		this.expenseToday = expenseToday;
	}

	public void setCashBalanceToday(int cashBalanceToday) {
		this.cashBalanceToday = cashBalanceToday;
	}

	public void setSavingsToday(int savingsToday) {
		this.savingsToday = savingsToday;
	}

	public void setRollingTomorrow(int rollingTomorrow) {
		this.rollingTomorrow = rollingTomorrow;
	}

	public void setAddRollingFromBox(int addRollingFromBox) {
		this.addRollingFromBox = addRollingFromBox;
	}

	public void setAddRollingFromTotalSavings(int addRollingFromTotalSavings) {
		this.addRollingFromTotalSavings = addRollingFromTotalSavings;
	}

	public void setSavingsToRemoveBoxDeficit(int savingsToRemoveBoxDeficit) {
		this.savingsToRemoveBoxDeficit = savingsToRemoveBoxDeficit;
	}

	public void setUrbanCollection(int urbanCollection) {
		this.urbanCollection = urbanCollection;
	}

	public void setElectricity(int electricity) {
		this.electricity = electricity;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}

	public void setAmountToMoveFromTotalSavingsToBank(int amountToMoveFromTotalSavingsToBank) {
		this.amountToMoveFromTotalSavingsToBank = amountToMoveFromTotalSavingsToBank;
	}

	public void setBooleanMoveEntireBoxAmountToTotalSavings(boolean moveBoxAmountToTotalSavings) {
		this.moveBoxAmountToTotalSavings = moveBoxAmountToTotalSavings;
	}

	public int getEmp1Salary() {
		return emp1Salary;
	}

	public void setEmp1Salary(int emp1Salary) {
		this.emp1Salary = emp1Salary;
	}

	public int getEmp2Salary() {
		return emp2Salary;
	}

	public void setEmp2Salary(int emp2Salary) {
		this.emp2Salary = emp2Salary;
	}

	public int getEmp1Bonus() {
		return emp1Bonus;
	}

	public void setEmp1Bonus(int emp1Bonus) {
		this.emp1Bonus = emp1Bonus;
	}

	public int getEmp2Bonus() {
		return emp2Bonus;
	}

	public void setEmp2Bonus(int emp2Bonus) {
		this.emp2Bonus = emp2Bonus;
	}

	public int getEmp3Bonus() {
		return emp3Bonus;
	}

	public void setEmp3Bonus(int emp3Bonus) {
		this.emp3Bonus = emp3Bonus;
	}

	public int getAddWithdrawlFromTS() {
		return addWithdrawlFromTS;
	}

	public void setAddWithdrawlFromTS(int addWithdrawlFromTS) {
		this.addWithdrawlFromTS = addWithdrawlFromTS;
	}

	//Sales
	public HashMap<String, String> generateSales() {
		String date = getDate();

		//1) Additional Rolling From Savings
		int additionalRollAmtFromTotalSavings = getAddRollingFromTotalSavings();
		//1) Additional Rolling From Box
		int additionalRollAmtFromBox = getAddRollingFromBox();

		int prevRollingAmt = getPrevRolling()+additionalRollAmtFromTotalSavings+additionalRollAmtFromBox;
		int expenseAmt = getExpenseToday();
		int cashBalance = getCashBalanceToday();//use updated cashBalance2

		int bonusAmt = getBonus();
		//1) Cash Balance
		int cashBalanceAfterBonus = getCashBalanceToday()-bonusAmt;

		//1) Today Business
		int businessToday = expenseAmt+cashBalance-prevRollingAmt;

		//1) Savings Today
		int savingsToday = getSavingsToday();//TODO <= cashBalance2

		//1) Savings to remove box deficit
		int savingsToRemoveBoxDeficit = getSavingsToRemoveBoxDeficit(); // TODO <=cashbalance2 & including daily 300 box amount, if >300 only to remove deficit

		int prevBoxDeficit = getPrevBoxDeficit();

		//1) Box Deficit //TODO - add
		int boxDeficitToday = prevBoxDeficit + additionalRollAmtFromBox;

		int boxDeficitDifference = 0;
		if(savingsToRemoveBoxDeficit>0) { // TODO - 300? or 0?, includes box amount?
			boxDeficitDifference = boxDeficitToday - (savingsToRemoveBoxDeficit); // Reduce the deficit by removing the today box
		}

		//2) Rolling for Tomorrow - additionalRollFromTS1
		int rollingAmtForTomorrow = getRollingTomorrow() ;//cashBalance1-savingsToday1 //but enters manually //cashBalance2-savingsToday1

		//1) Urban collection
		int urbanCollectionAmt = getUrbanCollection();

		//1) Total Saving Amount to Bank Account;
		int amtTransferredFromTotalSavingsToBank = getAmountToMoveFromTotalSavingsToBank();

		int prevTotalSavings = getPrevTotalSavings() - additionalRollAmtFromTotalSavings;
		//3) Total Savings - Additional Rolling From Box - amountToBankAcc1
		int totalSavingsToday = prevTotalSavings + savingsToday - urbanCollectionAmt - amtTransferredFromTotalSavingsToBank - getAddWithdrawlFromTS();

		//1) Electricity
		int electricity = getElectricity();

		//1) Salary
		int salary = getSalary();

		int prevBoxSavings = getPrevBoxSavings() - additionalRollAmtFromBox;
		//1) Total Box Savings
		int boxSavingsToday =  prevBoxSavings + 300 + savingsToRemoveBoxDeficit - electricity - salary;
		if(boxDeficitDifference<0) {//if there is no deficit for box, add amount to box
			boxSavingsToday = boxSavingsToday + (-1*boxDeficitDifference);
			boxDeficitToday = 0;//set this to zero
		}

		//1) Transfer entire Box Amount to Total Savings
		int boxAmtTransfferedToTS = 0;
		boolean isBoxAmtTransfferedToTS = isBoxAmtTransfferedToTotalSavings();
		if(isBoxAmtTransfferedToTS) {
			totalSavingsToday = totalSavingsToday + boxSavingsToday;
			boxAmtTransfferedToTS = boxSavingsToday;
			boxSavingsToday = 0;//set this in excel for next day BOX_SAVINGS
		}

		salesToday.put("DATE",date);
		salesToday.put("PREV_ROLLING",prevRollingAmt+"");
		salesToday.put("EXPENSE",expenseAmt+"");
		salesToday.put("CASH_BAL",cashBalance+"");
		salesToday.put("BONUS",bonusAmt+"");
		salesToday.put("CASH_BAL_AFTER_BONUS",cashBalanceAfterBonus+"");
		salesToday.put("BUSINESS_TODAY",businessToday+"");
		salesToday.put("ADDITIONAL_ROLL_BOX",additionalRollAmtFromBox+"");
		salesToday.put("ADDITIONAL_ROLL_TS",additionalRollAmtFromTotalSavings+"");
		salesToday.put("ROLL_TOMORROW",rollingAmtForTomorrow+"");
		salesToday.put("PREV_BOX_DEFICIT",prevBoxDeficit+"");
		salesToday.put("SAVINGS_TO_REDUCE_BOX_DEFICIT",savingsToRemoveBoxDeficit+"");
		salesToday.put("BOX_DEFICIT_TODAY",boxDeficitToday+"");
		salesToday.put("ELECTRICITY",electricity+"");
		salesToday.put("SALARY",salary+"");
		salesToday.put("PREV_BOX_SAVINGS",prevBoxSavings+"");
		salesToday.put("BOX_SAVINGS_TODAY",boxSavingsToday+"");
		salesToday.put("BOX_AMT_TO_TS",boxAmtTransfferedToTS+"");
		salesToday.put("URBAN_COLLECTION",urbanCollectionAmt+"");
		salesToday.put("PREV_TOTAL_SAVINGS",prevTotalSavings+"");
		salesToday.put("SAVINGS_TODAY",savingsToday+"");
		salesToday.put("TOTAL_SAVINGS_TODAY",totalSavingsToday+"");
		salesToday.put("TRANSFERRED_TS_TO_BANK",amtTransferredFromTotalSavingsToBank+"");

		salesToday.put("EMP1_SALARY",emp1Salary+"");
		salesToday.put("EMP2_SALARY",emp2Salary+"");
		salesToday.put("EMP1_BONUS",emp1Bonus+"");
		salesToday.put("EMP2_BONUS",emp2Bonus+"");
		salesToday.put("EMP3_BONUS",emp3Bonus+"");
		salesToday.put("ADD_WITHDRAWL_TS",addWithdrawlFromTS+"");

		return salesToday;
	}
}
